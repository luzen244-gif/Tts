using System.Globalization;
using LzKeyMap.Core.Execution;

namespace LzKeyMap.Converters;

/// <summary>
/// Substitui o BoolToStatusColorConverter da Fase 1 (mesmo nome/uso), generalizado:
/// aceita bool (true=verde, false=vermelho) OU ExecutorAvailability (Available=verde,
/// NeedsUserAction=âmbar, Unsupported=vermelho). ConverterParameter="text" devolve o texto do estado.
/// </summary>
public class BoolToStatusColorConverter : IValueConverter
{
    static readonly Color Green = Color.FromArgb("#22C55E");
    static readonly Color Amber = Color.FromArgb("#F59E0B");
    static readonly Color Red = Color.FromArgb("#EF4444");
    static readonly Color Gray = Color.FromArgb("#6B7280");

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        bool text = parameter as string == "text";
        if (parameter as string == "granted" && value is ExecutorAvailability g)
            return g switch
            {
                ExecutorAvailability.Available => "Concedida",
                ExecutorAvailability.NeedsUserAction => "Pendente",
                _ => "Indisponível"
            };
        switch (value)
        {
            case bool b:
                return text ? (b ? "Ativo" : "Inativo") : (b ? Green : Red);
            case ExecutorAvailability a:
                return a switch
                {
                    ExecutorAvailability.Available => text ? "Funcionando" : Green,
                    ExecutorAvailability.NeedsUserAction => text ? "Precisa de ação sua" : Amber,
                    ExecutorAvailability.Unsupported => text ? "Não suportado" : Red,
                    _ => text ? "Desconhecido" : Gray
                };
            default:
                return text ? "Desconhecido" : Gray;
        }
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => throw new NotSupportedException();
}
