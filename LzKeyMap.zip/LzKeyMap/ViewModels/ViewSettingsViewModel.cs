using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using LzKeyMap.Core.Abstractions;
using LzKeyMap.Core.Execution;
using LzKeyMap.Core.Models;
using LzKeyMap.Core.Storage;

namespace LzKeyMap.ViewModels;

public partial class ViewSettingsViewModel : ObservableObject
{
    public const double SensMin = 0.01, SensMax = 5.0, SensStep = 0.01;

    readonly ProfileStore store;
    readonly IExecutionManager execution;
    bool loading;

    public ObservableCollection<OutputFrequencyHz> Frequencies { get; } =
        new(Enum.GetValues<OutputFrequencyHz>());

    [ObservableProperty] string profileName = "";
    [ObservableProperty] bool hasProfile;
    [ObservableProperty] double sensitivityX = 1, sensitivityY = 1;
    [ObservableProperty] OutputFrequencyHz frequency;
    [ObservableProperty] bool invertX, invertY, lockHudEditing;
    [ObservableProperty] double deadZone, smoothing, mouseSpeed = 1;
    [ObservableProperty] string frequencyNote = "";
    [ObservableProperty] string status = "";

    public ViewSettingsViewModel(ProfileStore store, IExecutionManager execution)
    {
        this.store = store;
        this.execution = execution;
    }

    public void Load()
    {
        var p = EditorSession.Profile;
        HasProfile = p != null;
        if (p == null)
        {
            ProfileName = "";
            Status = "Nenhum HUD selecionado. Abra o Gerenciador de HUDs, escolha um HUD e toque em \"Vista…\".";
            return;
        }
        Apply(p.View ?? ViewSettings.Defaults());
        ProfileName = p.Name;
        Status = "";
    }

    void Apply(ViewSettings v)
    {
        loading = true;
        SensitivityX = v.SensitivityX; SensitivityY = v.SensitivityY;
        Frequency = v.Frequency;
        InvertX = v.InvertX; InvertY = v.InvertY;
        DeadZone = v.DeadZone; Smoothing = v.Smoothing; MouseSpeed = v.MouseSpeed;
        LockHudEditing = v.LockHudEditing;
        loading = false;
        UpdateFrequencyNote();
    }

    // Slider, campo numérico e botões +/- usam a MESMA propriedade: ficam sincronizados.
    static double Round(double v) => Math.Round(Math.Clamp(v, SensMin, SensMax), 2);
    partial void OnSensitivityXChanged(double value) { if (!loading && value != Round(value)) SensitivityX = Round(value); }
    partial void OnSensitivityYChanged(double value) { if (!loading && value != Round(value)) SensitivityY = Round(value); }
    partial void OnFrequencyChanged(OutputFrequencyHz value) => UpdateFrequencyNote();

    [RelayCommand] void XPlus() => SensitivityX = Round(SensitivityX + SensStep);
    [RelayCommand] void XMinus() => SensitivityX = Round(SensitivityX - SensStep);
    [RelayCommand] void YPlus() => SensitivityY = Round(SensitivityY + SensStep);
    [RelayCommand] void YMinus() => SensitivityY = Round(SensitivityY - SensStep);

    /// <summary>Nunca esconde a diferença entre o Hz pedido e o que o método ativo sustenta.</summary>
    void UpdateFrequencyNote()
    {
        var ex = execution.Active;
        int wanted = Convert.ToInt32(Frequency);
        if (ex == null)
            FrequencyNote = "Nenhum método de execução ativo agora: não dá para saber o limite real. Inicie o motor na Home.";
        else if (ex.MaxSustainableHz < wanted)
            FrequencyNote = $"Limite real do método ativo ({ex.Name}): {ex.MaxSustainableHz} Hz. Você pediu {wanted} Hz — o valor realmente aplicado será {ex.MaxSustainableHz} Hz.";
        else
            FrequencyNote = $"Método ativo ({ex.Name}) sustenta até {ex.MaxSustainableHz} Hz — {wanted} Hz é viável.";
    }

    [RelayCommand]
    void Save()
    {
        var p = EditorSession.Profile;
        if (p == null) { Status = "Nenhum HUD selecionado."; return; }
        try
        {
            p.View = new ViewSettings
            {
                SensitivityX = SensitivityX, SensitivityY = SensitivityY,
                Frequency = Frequency,
                InvertX = InvertX, InvertY = InvertY,
                DeadZone = DeadZone, Smoothing = Smoothing, MouseSpeed = MouseSpeed,
                LockHudEditing = LockHudEditing
            };
            store.Save(p);
            EditorSession.RaiseSaved();
            Status = "Configurações salvas.";
        }
        catch (Exception ex) { Status = "Falha ao salvar: " + ex.Message; }
    }

    [RelayCommand]
    void RestoreDefaults()
    {
        Apply(ViewSettings.Defaults());
        Status = "Padrões carregados na tela. Toque em SALVAR para gravar.";
    }
}
