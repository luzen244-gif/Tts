using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using LzKeyMap.Core.Abstractions;
using LzKeyMap.Core.Execution;
using LzKeyMap.Core.Permissions;

namespace LzKeyMap.ViewModels;

public partial class PermissionsViewModel : ObservableObject
{
    readonly PermissionManager permissions;
    readonly ISystemSettingsLauncher settings;
    readonly IExecutionManager execution;
    IDispatcherTimer? timer;

    public ObservableCollection<PermissionInfo> Items { get; } = new();
    [ObservableProperty] string status = "";

    public PermissionsViewModel(PermissionManager permissions, ISystemSettingsLauncher settings, IExecutionManager execution)
    {
        this.execution = execution;
        this.permissions = permissions;
        this.settings = settings;
    }

    public void Start()
    {
        Refresh();
        // O usuário volta das telas de sistema e o estado muda sem evento: reconsulta o estado real a cada 2 s.
        timer = Application.Current!.Dispatcher.CreateTimer();
        timer.Interval = TimeSpan.FromSeconds(2);
        timer.Tick += (_, _) => Refresh();
        timer.Start();
    }

    public void Stop() { timer?.Stop(); timer = null; }

    [RelayCommand]
    public void Refresh()
    {
        var fresh = permissions.GetAll();
        // atualiza no lugar para não perder rolagem/seleção
        if (Items.Count != fresh.Count || !Items.Select(i => i.Id).SequenceEqual(fresh.Select(f => f.Id)))
        {
            Items.Clear();
            foreach (var f in fresh) Items.Add(f);
            return;
        }
        for (int i = 0; i < fresh.Count; i++)
            if (!Equals(Items[i], fresh[i])) Items[i] = fresh[i];
    }

    [RelayCommand]
    void Configure(PermissionInfo item)
    {
        if (!settings.Open(item.Id, out var msg) || !string.IsNullOrEmpty(msg))
            Status = $"{item.Name}: {msg}";
        else
            Status = "";
    }

    /// <summary>Verifica de verdade Root/Shizuku/ADB (su, Shizuku, sockets) em segundo plano e atualiza a lista.</summary>
    [RelayCommand]
    async Task VerifyAll()
    {
        Status = "Verificando… (o Root pode abrir o pedido do Magisk/KernelSU)";
        await Task.Run(() => execution.VerifyAll());
        Refresh();
        Status = "Verificação concluída.";
    }
}
