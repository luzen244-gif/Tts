using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using LzKeyMap.Core.Abstractions;
using LzKeyMap.Core.Storage;

namespace LzKeyMap.ViewModels;

/// <summary>"Escolher aplicativo": todos os apps lançáveis do aparelho (PackageManager), com busca por nome ou pacote.</summary>
public partial class AppPickerViewModel : ObservableObject
{
    readonly IGameCatalog games;
    readonly ChosenAppsStore chosen;
    List<InstalledApp> all = new();

    public ObservableCollection<InstalledApp> Items { get; } = new();

    [ObservableProperty] string search = "";
    [ObservableProperty] bool isBusy;
    [ObservableProperty] string status = "";

    public AppPickerViewModel(IGameCatalog games, ChosenAppsStore chosen)
    {
        this.games = games; this.chosen = chosen;
    }

    public async Task LoadAsync()
    {
        IsBusy = true;
        try { all = (await games.GetLaunchableAppsAsync()).ToList(); Filter(); }
        catch (Exception ex) { Status = "Falha ao listar apps: " + ex.Message; }
        finally { IsBusy = false; }
    }

    partial void OnSearchChanged(string value) => Filter();

    void Filter()
    {
        var already = chosen.GetPackages();
        IEnumerable<InstalledApp> q = all.Where(a => !already.Contains(a.PackageName));
        if (!string.IsNullOrWhiteSpace(Search))
            q = q.Where(a => a.Label.Contains(Search, StringComparison.CurrentCultureIgnoreCase)
                          || a.PackageName.Contains(Search, StringComparison.OrdinalIgnoreCase));
        Items.Clear();
        foreach (var a in q) Items.Add(a);
        Status = Items.Count == 0
            ? (all.Count == 0 ? "Nenhum app encontrado. No Android 11+ o manifest precisa do bloco <queries> (ver AndroidManifest.xml)." : "Nada encontrado.")
            : "Toque para selecionar.";
    }

    [RelayCommand]
    async Task Pick(InstalledApp app)
    {
        chosen.Add(app.PackageName);
        await Shell.Current.GoToAsync("..");
    }
}
