using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using LzKeyMap.Core.Abstractions;
using LzKeyMap.Core.Devices;
using LzKeyMap.Core.Execution;
using LzKeyMap.Core.Permissions;
using LzKeyMap.Core.Storage;

namespace LzKeyMap.ViewModels;

/// <summary>
/// Home no layout novo. Substitui (ou convive com) o MainPageViewModel da Fase 1: o início/parada do motor
/// passa pela fachada IEngineController, que você liga ao código que o INICIAR da Fase 1 já usa.
/// </summary>
public partial class HomeViewModel : ObservableObject
{
    readonly ChosenAppsStore chosen;
    readonly IGameCatalog games;
    readonly ProfileStore store;
    readonly IEngineController engine;
    readonly PermissionManager permissions;
    readonly DeviceManager devices;
    readonly IExecutionManager execution;
    readonly ISystemSettingsLauncher settings;

    public ObservableCollection<InstalledApp> Apps { get; } = new();
    public ObservableCollection<PermissionInfo> Permissions { get; } = new();

    [ObservableProperty] InstalledApp? selectedApp;
    [ObservableProperty] string motorTitle = "MOTOR";
    [ObservableProperty] ExecutorAvailability motorState = ExecutorAvailability.NeedsUserAction;
    [ObservableProperty] string motorText = "Toque em VERIFICAR para checar o método de execução.";
    [ObservableProperty] string deviceKind = "MOUSE";
    [ObservableProperty] string deviceName = "Nenhum detectado";
    [ObservableProperty] string deviceState = "";
    [ObservableProperty] bool isRunning;
    [ObservableProperty] string startText = "▶  INICIAR";
    [ObservableProperty] string status = "";

    public HomeViewModel(ChosenAppsStore chosen, IGameCatalog games, ProfileStore store, IEngineController engine,
        PermissionManager permissions, DeviceManager devices, IExecutionManager execution, ISystemSettingsLauncher settings)
    {
        this.chosen = chosen; this.games = games; this.store = store; this.engine = engine;
        this.permissions = permissions; this.devices = devices; this.execution = execution; this.settings = settings;
    }

    static Page? Current => Shell.Current?.CurrentPage;

    public async Task LoadAsync()
    {
        var all = await games.GetLaunchableAppsAsync();
        var wanted = chosen.GetPackages();
        var keep = SelectedApp?.PackageName;
        Apps.Clear();
        foreach (var pkg in wanted)
        {
            // app que foi desinstalado some da lista, mas continua escolhido até o usuário remover
            var app = all.FirstOrDefault(a => a.PackageName == pkg);
            if (app != null) Apps.Add(app);
        }
        SelectedApp = Apps.FirstOrDefault(a => a.PackageName == keep) ?? Apps.FirstOrDefault();
        RefreshPermissions();
        RefreshDevice();
        SyncRunning();
    }

    void SyncRunning()
    {
        IsRunning = engine.IsRunning;
        StartText = IsRunning ? "■  PARAR" : "▶  INICIAR";
    }

    [RelayCommand]
    void RefreshPermissions()
    {
        Permissions.Clear();
        foreach (var p in permissions.GetAll()) Permissions.Add(p);
    }

    void RefreshDevice()
    {
        var d = devices.GetDevices().FirstOrDefault(x => x.Kind == "mouse")
                ?? devices.GetDevices().FirstOrDefault(x => x.Kind == "keyboard");
        if (d == null) { DeviceKind = "DISPOSITIVO"; DeviceName = "Nenhum detectado"; DeviceState = "● Desconectado"; return; }
        DeviceKind = d.Kind == "mouse" ? "MOUSE" : "TECLADO";
        DeviceName = d.Name;
        DeviceState = "● " + d.State;
    }

    /// <summary>Verificação MANUAL do método de execução (roda `su`/sockets: sempre em thread de fundo).</summary>
    [RelayCommand]
    async Task CheckMotor()
    {
        MotorText = "Verificando…";
        var ex = await Task.Run(() => execution.Refresh());
        RefreshPermissions();
        if (ex == null)
        {
            MotorTitle = "MOTOR";
            MotorState = ExecutorAvailability.NeedsUserAction;
            MotorText = "Nenhum método de execução disponível. Veja a tela de Permissões.";
            return;
        }
        var st = ex.LastStatus ?? new ExecutorStatus(ExecutorAvailability.NeedsUserAction, "sem resultado");
        MotorTitle = "MOTOR " + ex.Name.ToUpperInvariant();
        MotorState = st.State;
        MotorText = st.Explanation;
    }

    /// <summary>Alterna o método preferido (Acessibilidade → Root → Shizuku → ADB → automático) e reverifica.</summary>
    [RelayCommand]
    async Task CycleMotor()
    {
        var names = execution.All.Select(e => e.Name).ToList();
        var cur = execution.Preferred;
        int i = cur == null ? -1 : names.IndexOf(cur);
        execution.Preferred = i + 1 < names.Count ? names[i + 1] : null;
        Status = execution.Preferred == null ? "Método: automático." : $"Método preferido: {execution.Preferred}.";
        await CheckMotor();
    }

    [RelayCommand] Task AddApp() => Shell.Current.GoToAsync("pickapp");
    [RelayCommand] Task OpenHudManager() => Shell.Current.GoToAsync("hudmanager");
    [RelayCommand] Task OpenDevices() => Shell.Current.GoToAsync("devices");
    [RelayCommand] Task OpenPermissions() => Shell.Current.GoToAsync("permissions");

    [RelayCommand]
    async Task RemoveApp()
    {
        if (SelectedApp == null) { Status = "Selecione um app para remover."; return; }
        if (!await Current!.DisplayAlert("Remover app", $"Tirar \"{SelectedApp.Label}\" da lista? Os HUDs dele não são apagados.", "Remover", "Cancelar")) return;
        chosen.Remove(SelectedApp.PackageName);
        await LoadAsync();
    }

    [RelayCommand]
    void OpenPermission(PermissionInfo item)
    {
        if (!settings.Open(item.Id, out var msg) || !string.IsNullOrEmpty(msg)) Status = $"{item.Name}: {msg}";
    }

    [RelayCommand]
    async Task ToggleStart()
    {
        if (engine.IsRunning) { engine.Stop(); SyncRunning(); Status = "Motor parado."; return; }

        if (SelectedApp == null) { Status = "Escolha um app (+ APP) e selecione-o antes de iniciar."; return; }
        var huds = store.GetHudsForGame(SelectedApp.PackageName);
        var activeId = chosen.GetActiveHudId(SelectedApp.PackageName);
        var hud = huds.FirstOrDefault(h => h.Id == activeId) ?? huds.FirstOrDefault();
        if (hud == null) { Status = "Este jogo ainda não tem HUD. Crie um no Gerenciador de HUDs."; return; }

        var error = await engine.StartAsync(hud);
        SyncRunning();
        if (error != null) { Status = "Não foi possível iniciar: " + error; return; }

        await CheckMotor();
        var name = execution.Active?.Name.ToUpperInvariant() ?? "";
        bool launched = games.Launch(SelectedApp.PackageName);
        Status = (launched
            ? $"Motor {name} ativo. Jogo iniciado: {SelectedApp.Label}."
            : $"Motor {name} ativo, mas não consegui abrir {SelectedApp.Label}. Abra-o manualmente.")
            + (string.IsNullOrEmpty(engine.Note) ? "" : " " + engine.Note);
    }
}
