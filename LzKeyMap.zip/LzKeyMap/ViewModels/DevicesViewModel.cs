using System.Collections.Concurrent;
using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using LzKeyMap.Core.Devices;

namespace LzKeyMap.ViewModels;

public partial class DevicesViewModel : ObservableObject
{
    readonly DeviceManager devices;
    readonly ConcurrentQueue<RawInputEvent> queue = new();
    IDispatcherTimer? timer;
    float accDx, accDy;

    public ObservableCollection<string> Log { get; } = new();

    [ObservableProperty] string keyboardName = "—";
    [ObservableProperty] string keyboardInfo = "";
    [ObservableProperty] string mouseName = "—";
    [ObservableProperty] string mouseInfo = "";
    [ObservableProperty] long totalEvents;
    [ObservableProperty] int distinctKeys;
    [ObservableProperty] int distinctMouseButtons;
    [ObservableProperty] string lastEvent = "nenhum evento recebido ainda";
    [ObservableProperty] string mouseDelta = "Δ mouse: 0, 0";
    [ObservableProperty] bool testMode;
    [ObservableProperty] string testButtonText = "TESTAR DISPOSITIVO";
    [ObservableProperty] string mouseNote =
        "Mouse (botões/movimento) só é capturado com Root + leitor evdev. Sem Root, só o teclado aparece aqui.";

    public DevicesViewModel(DeviceManager devices) => this.devices = devices;

    public void Start()
    {
        RefreshDevices();
        InputEventHub.EventReceived += OnEvent;
        timer = Application.Current!.Dispatcher.CreateTimer();
        timer.Interval = TimeSpan.FromMilliseconds(100);   // UI a ≤10 Hz, mesmo com mouse a 1000 Hz
        timer.Tick += (_, _) => Drain();
        timer.Start();
    }

    public void Stop()
    {
        InputEventHub.EventReceived -= OnEvent;
        timer?.Stop();
        timer = null;
        if (TestMode) SetTest(false);
    }

    [RelayCommand]
    public void RefreshDevices()
    {
        var list = devices.GetDevices();
        var kb = list.FirstOrDefault(d => d.Kind == "keyboard");
        var ms = list.FirstOrDefault(d => d.Kind == "mouse");
        KeyboardName = kb?.Name ?? "Nenhum teclado detectado";
        KeyboardInfo = kb == null ? "" : $"{kb.Connection} · {kb.State}";
        MouseName = ms?.Name ?? "Nenhum mouse detectado";
        MouseInfo = ms == null ? "" : $"{ms.Connection} · {ms.State}";
    }

    [RelayCommand]
    void ToggleTest() => SetTest(!TestMode);

    [RelayCommand]
    void ResetCounters()
    {
        InputEventHub.ResetCounters();
        Log.Clear();
        LastEvent = "contadores zerados";
        Drain();
    }

    void SetTest(bool on)
    {
        TestMode = on;
        InputEventHub.TestMode = on;   // o motor deixa de despachar toques enquanto true
        TestButtonText = on ? "SAIR DO TESTE" : "TESTAR DISPOSITIVO";
        if (on) Log.Clear();
    }

    void OnEvent(RawInputEvent e)
    {
        queue.Enqueue(e);
        while (queue.Count > 500) queue.TryDequeue(out _);
    }

    void Drain()
    {
        while (queue.TryDequeue(out var e))
        {
            switch (e.Kind)
            {
                case InputEventKind.MouseMove:
                    accDx += e.Dx; accDy += e.Dy;
                    break;
                case InputEventKind.Key:
                    LastEvent = $"tecla {e.Description} ({(e.Down ? "pressionada" : "solta")})";
                    if (TestMode) AddLog($"{e.Time:HH:mm:ss.fff}  tecla {e.Description} {(e.Down ? "↓" : "↑")}");
                    break;
                case InputEventKind.MouseButton:
                    LastEvent = $"botão do mouse {e.Description} ({(e.Down ? "pressionado" : "solto")})";
                    if (TestMode) AddLog($"{e.Time:HH:mm:ss.fff}  mouse {e.Description} {(e.Down ? "↓" : "↑")}");
                    break;
            }
        }
        if (accDx != 0 || accDy != 0)
        {
            MouseDelta = $"Δ mouse: {accDx:F0}, {accDy:F0}";
            if (TestMode) AddLog($"mouse move  Δx={accDx:F0}  Δy={accDy:F0}");
            accDx = accDy = 0;
        }
        TotalEvents = InputEventHub.TotalEvents;
        DistinctKeys = InputEventHub.DistinctKeys;
        DistinctMouseButtons = InputEventHub.DistinctMouseButtons;
    }

    void AddLog(string line)
    {
        Log.Insert(0, line);
        while (Log.Count > 60) Log.RemoveAt(Log.Count - 1);
    }
}
