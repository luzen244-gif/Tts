using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using LzKeyMap.Core.Abstractions;
using LzKeyMap.Core.Models;
using LzKeyMap.Core.Storage;

namespace LzKeyMap.ViewModels;

/// <summary>HUDs por jogo. Cada jogo escolhido na Home tem os seus HUDs; toda gravação passa pelo ProfileStore.</summary>
public partial class HudManagerViewModel : ObservableObject
{
    readonly ProfileStore store;
    readonly IGameCatalog games;
    readonly IFileTransfer files;
    readonly IHudEditorLauncher editor;
    readonly ChosenAppsStore chosen;

    public ObservableCollection<InstalledApp> Apps { get; } = new();
    public ObservableCollection<HudProfile> Huds { get; } = new();

    [ObservableProperty] InstalledApp? selectedApp;
    [ObservableProperty] HudProfile? selectedHud;
    [ObservableProperty] string activeHudText = "";
    [ObservableProperty] string status = "";

    public HudManagerViewModel(ProfileStore store, IGameCatalog games, IFileTransfer files, IHudEditorLauncher editor, ChosenAppsStore chosen)
    {
        this.store = store; this.games = games; this.files = files; this.editor = editor; this.chosen = chosen;
    }

    static Page? CurrentPage => Shell.Current?.CurrentPage;
    static Task Alert(string title, string msg) => CurrentPage?.DisplayAlert(title, msg, "OK") ?? Task.CompletedTask;

    public async Task LoadAsync()
    {
        var all = await games.GetLaunchableAppsAsync();
        var keep = SelectedApp?.PackageName;
        Apps.Clear();
        foreach (var pkg in chosen.GetPackages())
        {
            var app = all.FirstOrDefault(a => a.PackageName == pkg);
            if (app != null) Apps.Add(app);
        }
        SelectedApp = Apps.FirstOrDefault(a => a.PackageName == keep) ?? Apps.FirstOrDefault();
        if (Apps.Count == 0) Status = "Nenhum jogo escolhido. Use + APP na Home ou abaixo.";
    }

    partial void OnSelectedAppChanged(InstalledApp? value) => RefreshHuds();

    void RefreshHuds(string? selectId = null)
    {
        var keep = selectId ?? SelectedHud?.Id;
        Huds.Clear();
        if (SelectedApp == null) { SelectedHud = null; ActiveHudText = ""; return; }
        foreach (var h in store.GetHudsForGame(SelectedApp.PackageName)) Huds.Add(h);
        SelectedHud = Huds.FirstOrDefault(h => h.Id == keep);
        var active = Huds.FirstOrDefault(h => h.Id == chosen.GetActiveHudId(SelectedApp.PackageName));
        ActiveHudText = active != null ? $"HUD em uso neste jogo: {active.Name}"
            : Huds.Count > 0 ? $"Nenhum HUD marcado como em uso (será usado: {Huds[0].Name})." : "Este jogo ainda não tem HUD.";
    }

    bool Need(bool app, bool hud)
    {
        if (app && SelectedApp == null) { _ = Alert("Jogo", "Selecione um jogo primeiro."); return false; }
        if (hud && SelectedHud == null) { _ = Alert("HUD", "Nenhum HUD selecionado."); return false; }
        return true;
    }

    [RelayCommand] Task AddApp() => Shell.Current.GoToAsync("pickapp");

    [RelayCommand]
    void UseHere()
    {
        if (!Need(true, true)) return;
        chosen.SetActiveHudId(SelectedApp!.PackageName, SelectedHud!.Id);
        RefreshHuds(SelectedHud.Id);
        Status = $"\"{SelectedHud.Name}\" será usado neste jogo.";
    }

    [RelayCommand]
    async Task CreateAsync()
    {
        if (!Need(true, false)) return;
        var name = await CurrentPage!.DisplayPromptAsync("Criar HUD", "Nome do HUD:", "Criar", "Cancelar", "Meu HUD");
        if (string.IsNullOrWhiteSpace(name)) return;
        try
        {
            var p = new HudProfile
            {
                Id = Guid.NewGuid().ToString("N"),
                Name = name.Trim(),
                GamePackage = SelectedApp!.PackageName,
                Components = new List<HudComponent>(),
                View = ViewSettings.Defaults()
            };
            store.Save(p);
            if (store.GetHudsForGame(p.GamePackage).Count() == 1) chosen.SetActiveHudId(p.GamePackage, p.Id);   // o primeiro vira o "em uso"
            RefreshHuds(p.Id);
        }
        catch (Exception ex) { await Alert("Erro ao criar", ex.Message); }
    }

    [RelayCommand]
    async Task EditAsync()
    {
        if (!Need(true, true)) return;
        if (!editor.Start(SelectedHud!, out var msg)) { await Alert("Editor", msg); return; }
        if (!games.Launch(SelectedApp!.PackageName))
            await Alert("Editor", "Barra de edição ativa, mas não consegui abrir o jogo. Abra-o manualmente.");
    }

    [RelayCommand]
    async Task RenameAsync()
    {
        if (!Need(true, true)) return;
        var name = await CurrentPage!.DisplayPromptAsync("Renomear HUD", "Novo nome:", "OK", "Cancelar", initialValue: SelectedHud!.Name);
        if (string.IsNullOrWhiteSpace(name) || name == SelectedHud.Name) return;
        try { var id = SelectedHud.Id; SelectedHud.Name = name.Trim(); store.Save(SelectedHud); RefreshHuds(id); }
        catch (Exception ex) { await Alert("Erro ao renomear", ex.Message); }
    }

    [RelayCommand]
    async Task DuplicateAsync()
    {
        if (!Need(true, true)) return;
        try
        {
            var copy = HudCloner.CloneProfile(SelectedHud!, SelectedHud!.Name + " (cópia)");
            store.Save(copy);
            RefreshHuds(copy.Id);
        }
        catch (Exception ex) { await Alert("Erro ao duplicar", ex.Message); }
    }

    [RelayCommand]
    async Task DeleteAsync()
    {
        if (!Need(true, true)) return;
        if (!await CurrentPage!.DisplayAlert("Excluir HUD", $"Excluir \"{SelectedHud!.Name}\"? Um backup é criado e pode ser restaurado.", "Excluir", "Cancelar")) return;
        try
        {
            store.Delete(SelectedHud);
            if (ReferenceEquals(EditorSession.Profile, SelectedHud)) EditorSession.Profile = null;
            RefreshHuds(null);
        }
        catch (Exception ex) { await Alert("Erro ao excluir", ex.Message); }
    }

    [RelayCommand]
    async Task RestoreAsync()
    {
        if (!Need(true, false)) return;
        try
        {
            var backups = store.GetBackups(SelectedApp!.PackageName);
            if (backups.Count == 0) { await Alert("Voltar backup", "Nenhum backup para este jogo."); return; }
            var names = backups.Select(System.IO.Path.GetFileName).Select(n => n ?? "?").ToArray();
            var pick = await CurrentPage!.DisplayActionSheet("Voltar backup", "Cancelar", null, names);
            var idx = Array.IndexOf(names, pick);
            if (idx < 0) return;
            var p = store.Import(backups[idx]);
            RefreshHuds(p.Id);
            Status = "Backup restaurado.";
        }
        catch (Exception ex) { await Alert("Erro ao restaurar", ex.Message); }
    }

    [RelayCommand]
    async Task ImportAsync()
    {
        if (!Need(true, false)) return;
        try
        {
            var path = await files.PickImportFileAsync();
            if (path == null) return;
            // valida arquivo inválido/versão incompatível (lança); o HUD passa a pertencer ao jogo selecionado e nunca sobrescreve outro
            var p = store.Import(path, SelectedApp!.PackageName);
            RefreshHuds(p.Id);
            Status = $"HUD \"{p.Name}\" importado.";
        }
        catch (Exception ex) { await Alert("Erro ao importar", ex.Message); }
    }

    [RelayCommand]
    async Task ExportAsync()
    {
        if (!Need(true, true)) return;
        var temp = System.IO.Path.Combine(FileSystem.CacheDirectory, $"export_{Guid.NewGuid():N}.json");
        try
        {
            store.Export(SelectedHud!, temp);
            if (await files.SaveExportFileAsync(temp, SelectedHud!.Name))
                Status = $"HUD \"{SelectedHud.Name}\" exportado.";
        }
        catch (Exception ex) { await Alert("Erro ao exportar", ex.Message); }
        finally { try { File.Delete(temp); } catch { } }
    }

    [RelayCommand]
    async Task OpenViewSettingsAsync()
    {
        if (!Need(true, true)) return;
        EditorSession.Profile = SelectedHud;
        await Shell.Current.GoToAsync("viewsettings");
    }
}
