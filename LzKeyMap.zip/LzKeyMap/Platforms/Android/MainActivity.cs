using Android.App;
using Android.Content;
using Android.Content.PM;
using LzKeyMap.Platforms.AndroidImpl;

namespace LzKeyMap;

[Activity(Name = "com.lz.keymap.MainActivity", Theme = "@style/Maui.SplashTheme", MainLauncher = true,
    LaunchMode = LaunchMode.SingleTop,
    ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.UiMode |
                           ConfigChanges.ScreenLayout | ConfigChanges.SmallestScreenSize | ConfigChanges.Density |
                           ConfigChanges.KeyboardHidden | ConfigChanges.Keyboard | ConfigChanges.Navigation)]
public class MainActivity : MauiAppCompatActivity
{
    protected override void OnActivityResult(int requestCode, Result resultCode, Intent? data)
    {
        base.OnActivityResult(requestCode, resultCode, data);
        AndroidFileTransfer.HandleActivityResult(requestCode, resultCode, data);   // seletor de arquivos (import/export)
    }

    protected override void OnNewIntent(Intent? intent)
    {
        base.OnNewIntent(intent);
        var route = intent?.GetStringExtra("route");
        if (!string.IsNullOrEmpty(route))
            MainThread.BeginInvokeOnMainThread(async () => await Shell.Current.GoToAsync(route));
    }
}
