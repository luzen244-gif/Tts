using Android.Content;
using LzKeyMap.Core.Abstractions;
using LzKeyMap.Core.Devices;
using LzKeyMap.Core.Execution;
using LzKeyMap.Core.Models;
using LzKeyMap.Services;

namespace LzKeyMap.Platforms.AndroidImpl;

/// <summary>Liga/desliga o motor de verdade: escolhe o método de execução, captura o mouse (Root) e inicia o serviço.</summary>
public sealed class EngineController : IEngineController
{
    readonly ExecutionManager exec;
    public EngineController(ExecutionManager exec) => this.exec = exec;

    public bool IsRunning => MappingForegroundService.IsRunning;
    public string? Note { get; private set; }

    public async Task<string?> StartAsync(HudProfile hud)
    {
        Note = null;
        if (IsRunning) return null;

        // verificações reais (su, Shizuku, sockets): fora da thread de UI
        var chosen = await Task.Run(() =>
        {
            var c = exec.Refresh();
            exec.All.FirstOrDefault(e => e.Name == "Root")?.CheckAvailability();   // o mouse depende de Root, qualquer que seja o método de toque
            return c;
        });
        if (chosen == null)
            return "nenhum método de execução disponível.\n" + exec.DescribeUnavailable();

        var notes = new List<string>();
        var root = exec.All.FirstOrDefault(e => e.Name == "Root");
        if (root?.LastStatus?.State == ExecutorAvailability.Available)
        {
            var (ok, msg) = await Task.Run(() => RawInputService.Instance.Start(grab: true));
            notes.Add(ok ? msg : "Mouse não capturado: " + msg);
        }
        else
        {
            notes.Add("Sem Root: só o teclado é mapeado (mouse e Vista indisponíveis).");
        }
        if (chosen.Name != "Acessibilidade" && LzKeyMapAccessibilityService.Instance == null)
            notes.Add("O teclado chega pelo serviço de Acessibilidade, que está desligado: ative-o ou nenhuma tecla será mapeada.");
        Note = string.Join(" ", notes);

        var ctx = Android.App.Application.Context;
        MappingForegroundService.PendingHud = hud;
        MappingForegroundService.PendingExecutor = chosen;
        try { ctx.StartForegroundService(new Intent(ctx, typeof(MappingForegroundService))); }
        catch (Exception ex)
        {
            RawInputService.Instance.Stop();
            return "o Android recusou iniciar o serviço: " + ex.Message;
        }

        for (int i = 0; i < 40 && !IsRunning; i++) await Task.Delay(50);
        if (!IsRunning)
        {
            RawInputService.Instance.Stop();
            return "o serviço do motor não iniciou.";
        }
        return null;
    }

    public void Stop()
    {
        var ctx = Android.App.Application.Context;
        ctx.StopService(new Intent(ctx, typeof(MappingForegroundService)));
        RawInputService.Instance.Stop();
    }
}
