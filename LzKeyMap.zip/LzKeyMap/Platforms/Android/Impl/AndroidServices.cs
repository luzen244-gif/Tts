using Android.Content;
using Android.Content.PM;
using Android.Provider;
using LzKeyMap.Core.Abstractions;
using LzKeyMap.Core.Devices;
using LzKeyMap.Core.Execution;
using LzKeyMap.Core.Models;
using LzKeyMap.Services;

namespace LzKeyMap.Platforms.AndroidImpl;

/// <summary>Lista apps lançáveis de verdade (PackageManager + CategoryLauncher). Sem lista fixa.</summary>
public sealed class AndroidGameCatalog : IGameCatalog
{
    public Task<IReadOnlyList<InstalledApp>> GetLaunchableAppsAsync() => Task.Run<IReadOnlyList<InstalledApp>>(() =>
    {
        var ctx = global::Android.App.Application.Context;
        var pm = ctx.PackageManager!;
        var intent = new Intent(Intent.ActionMain);
        intent.AddCategory(Intent.CategoryLauncher);

        var result = new List<InstalledApp>();
        // Overload antigo (PackageInfoFlags) funciona em todas as APIs; o novo ResolveInfoFlags só existe na 33+.
#pragma warning disable CA1422
        var resolved = pm.QueryIntentActivities(intent, PackageInfoFlags.MatchAll);
#pragma warning restore CA1422
        foreach (var ri in resolved)
        {
            var info = ri.ActivityInfo?.ApplicationInfo;
            if (info?.PackageName == null || info.PackageName == ctx.PackageName) continue;
            bool game = info.Category == ApplicationInfoCategory.Game
#pragma warning disable CA1422
                        || (info.Flags & ApplicationInfoFlags.IsGame) != 0;
#pragma warning restore CA1422
            result.Add(new InstalledApp(info.PackageName, ri.LoadLabel(pm)?.ToString() ?? info.PackageName, game));
        }
        return result.DistinctBy(a => a.PackageName)
                     .OrderByDescending(a => a.IsGame).ThenBy(a => a.Label, StringComparer.CurrentCultureIgnoreCase)
                     .ToList();
    });

    public bool Launch(string packageName)
    {
        var ctx = global::Android.App.Application.Context;
        var i = ctx.PackageManager!.GetLaunchIntentForPackage(packageName);
        if (i == null) return false;
        i.AddFlags(ActivityFlags.NewTask);
        ctx.StartActivity(i);
        return true;
    }
}

/// <summary>Import/export pelo seletor nativo (SAF). Não exige permissão de armazenamento.</summary>
public sealed class AndroidFileTransfer : IFileTransfer
{
    const int ReqImport = 0x4C01, ReqExport = 0x4C02;
    static TaskCompletionSource<Intent?>? pending;
    static int pendingRequest;

    /// <summary>Chamar de MainActivity.OnActivityResult.</summary>
    public static void HandleActivityResult(int requestCode, global::Android.App.Result resultCode, Intent? data)
    {
        if (requestCode != pendingRequest || pending == null) return;
        var tcs = pending; pending = null;
        tcs.TrySetResult(resultCode == global::Android.App.Result.Ok ? data : null);
    }

    static async Task<Intent?> Launch(Intent intent, int req)
    {
        var activity = Microsoft.Maui.ApplicationModel.Platform.CurrentActivity
            ?? throw new InvalidOperationException("Nenhuma Activity em primeiro plano.");
        pending?.TrySetResult(null);
        pending = new TaskCompletionSource<Intent?>();
        pendingRequest = req;
        activity.StartActivityForResult(intent, req);
        return await pending.Task;
    }

    public async Task<string?> PickImportFileAsync()
    {
        var intent = new Intent(Intent.ActionOpenDocument);
        intent.AddCategory(Intent.CategoryOpenable);
        intent.SetType("*/*");   // .json às vezes chega como octet-stream; o ProfileStore valida o conteúdo
        var data = await Launch(intent, ReqImport);
        var uri = data?.Data;
        if (uri == null) return null;

        var ctx = global::Android.App.Application.Context;
        var temp = System.IO.Path.Combine(ctx.CacheDir!.AbsolutePath, $"import_{Guid.NewGuid():N}.json");
        await using var input = ctx.ContentResolver!.OpenInputStream(uri)
            ?? throw new IOException("Não foi possível abrir o arquivo escolhido.");
        await using var output = File.Create(temp);
        await input.CopyToAsync(output);
        return temp;
    }

    public async Task<bool> SaveExportFileAsync(string sourcePath, string suggestedName)
    {
        var intent = new Intent(Intent.ActionCreateDocument);
        intent.AddCategory(Intent.CategoryOpenable);
        intent.SetType("application/json");
        intent.PutExtra(Intent.ExtraTitle, suggestedName.EndsWith(".json") ? suggestedName : suggestedName + ".json");
        var data = await Launch(intent, ReqExport);
        var uri = data?.Data;
        if (uri == null) return false;

        var ctx = global::Android.App.Application.Context;
        await using var output = ctx.ContentResolver!.OpenOutputStream(uri, "wt")
            ?? throw new IOException("Não foi possível gravar no destino escolhido.");
        await using var input = File.OpenRead(sourcePath);
        await input.CopyToAsync(output);
        return true;
    }
}

/// <summary>Inicia/para a barra flutuante + editor. Verifica a permissão de overlay de verdade.</summary>
public sealed class AndroidHudEditorLauncher : IHudEditorLauncher
{
    readonly IExecutionManager exec;
    public AndroidHudEditorLauncher(IExecutionManager exec) => this.exec = exec;

    public bool IsRunning => FloatingToolbarService.Running;

    public bool Start(HudProfile profile, out string message)
    {
        var ctx = global::Android.App.Application.Context;
        if (!Settings.CanDrawOverlays(ctx))
        {
            message = "Falta a permissão \"Sobrepor a outros apps\". Abra a tela de Permissões e conceda.";
            return false;
        }
        EditorSession.Profile = profile;
        // Root já verificado: liga a leitura do mouse (sem exclusividade) para dar para atribuir botões do mouse no editor
        if (exec.All.FirstOrDefault(e => e.Name == "Root")?.LastStatus?.State == ExecutorAvailability.Available && !MappingForegroundService.IsRunning)
            Task.Run(() => RawInputService.Instance.Start(grab: false));
        ctx.StartService(new Intent(ctx, typeof(FloatingToolbarService)));
        message = "Barra de edição ativa. Abra o jogo para editar sobre ele.";
        return true;
    }

    public void Stop()
    {
        var ctx = global::Android.App.Application.Context;
        var i = new Intent(ctx, typeof(FloatingToolbarService));
        i.PutExtra(FloatingToolbarService.ExtraStop, true);
        ctx.StartService(i);
        if (!MappingForegroundService.IsRunning) RawInputService.Instance.Stop();
    }
}

/// <summary>Abre a tela de sistema correta para cada permissão/método.</summary>
public sealed class AndroidSystemSettingsLauncher : ISystemSettingsLauncher
{
    readonly IExecutionManager exec;
    public AndroidSystemSettingsLauncher(IExecutionManager exec) => this.exec = exec;

    void VerifyInBackground(string executorName) =>
        Task.Run(() => exec.All.FirstOrDefault(e => e.Name == executorName)?.CheckAvailability());

    public bool Open(string permissionId, out string message)
    {
        var ctx = global::Android.App.Application.Context;
        Intent? i = null;
        message = "";
        switch (permissionId)
        {
            case "overlay":
                i = new Intent(Settings.ActionManageOverlayPermission, global::Android.Net.Uri.Parse("package:" + ctx.PackageName));
                break;
            case "accessibility":
                i = new Intent(Settings.ActionAccessibilitySettings);
                break;
            case "adb":
                VerifyInBackground("ADB");
                i = new Intent(Settings.ActionApplicationDevelopmentSettings);
                message = "Ative \"Depuração USB/sem fio\". O pareamento sem fio (Android 11+) ainda NÃO é suportado pelo app; o ADB só funciona na porta TCP clássica (adb tcpip).";
                break;
            case "shizuku":
                VerifyInBackground("Shizuku");
                i = ctx.PackageManager!.GetLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (i == null) { message = "App Shizuku não instalado."; return false; }
                break;
            case "root":
                VerifyInBackground("Root");
                message = "Root não tem tela de configuração: o Magisk/KernelSU concede su ao LzKeyMap. Verificando agora — se aparecer o pedido, conceda e volte aqui.";
                return false;
            default:
                message = "Permissão desconhecida.";
                return false;
        }
        i.AddFlags(ActivityFlags.NewTask);
        try { ctx.StartActivity(i); return true; }
        catch (ActivityNotFoundException) { message = "Esta tela não existe neste aparelho."; return false; }
    }
}
