using Android.Content;
using Android.Graphics;
using Android.Graphics.Drawables;
using Android.Widget;
using Color = Android.Graphics.Color;
using Button = Android.Widget.Button;

namespace LzKeyMap.Overlay;

/// <summary>Mesmas cores do LzTheme.xaml, para o overlay nativo.</summary>
internal static class Palette
{
    public static readonly Color Panel = Color.ParseColor("#F2170B1F");
    public static readonly Color PanelAlt = Color.ParseColor("#FF2A0F2E");
    public static readonly Color Pink = Color.ParseColor("#FF1F8E");
    public static readonly Color PinkDark = Color.ParseColor("#B3125F");
    public static readonly Color Text = Color.White;
    public static readonly Color Muted = Color.ParseColor("#B8A6C4");
    public static readonly Color Amber = Color.ParseColor("#F59E0B");
}

internal static class Ui
{
    public static int Dp(Context c, int v) => (int)(v * c.Resources!.DisplayMetrics!.Density);

    public static GradientDrawable Round(Context c, Color fill, Color stroke, int radiusDp, int strokeDp)
    {
        var g = new GradientDrawable();
        g.SetColor(fill);
        g.SetCornerRadius(Dp(c, radiusDp));
        if (strokeDp > 0) g.SetStroke(Dp(c, strokeDp), stroke);
        return g;
    }

    public static Button Btn(Context c, string text, Action onClick, bool primary = false, float size = 11)
    {
        var b = new Button(c) { Text = text, TextSize = size };
        b.SetAllCaps(false);
        b.SetMinHeight(0); b.SetMinimumHeight(0); b.SetMinWidth(0); b.SetMinimumWidth(0);
        b.SetPadding(Dp(c, 6), Dp(c, 8), Dp(c, 6), Dp(c, 8));
        b.SetTextColor(primary ? Color.ParseColor("#0B0610") : Palette.Text);
        b.Background = Round(c, primary ? Palette.Pink : Palette.PanelAlt, Palette.PinkDark, 8, primary ? 0 : 1);
        b.Click += (_, _) => onClick();
        return b;
    }

    public static TextView Label(Context c, string text, float size = 12, Color? color = null)
    {
        var t = new TextView(c) { Text = text, TextSize = size };
        t.SetTextColor(color ?? Palette.Text);
        return t;
    }
}
