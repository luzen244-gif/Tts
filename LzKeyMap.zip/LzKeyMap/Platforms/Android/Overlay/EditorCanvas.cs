using Android.Content;
using Android.Graphics;
using Android.Views;
using Android.Widget;
using LzKeyMap.Core.Devices;
using LzKeyMap.Core.Models;
using Color = Android.Graphics.Color;
using Paint = Android.Graphics.Paint;
using Button = Android.Widget.Button;
using Orientation = Android.Widget.Orientation;

namespace LzKeyMap.Overlay;

/// <summary>
/// Tela cheia de edição desenhada em overlay sobre o jogo. Tudo em coordenadas RELATIVAS (0..1):
/// centro = (RelativeX*W, RelativeY*H); diâmetro = RelativeSize * lado menor da tela.
/// Cada alteração é salva ao soltar o dedo / ao mudar uma propriedade, via o callback 'save'
/// (que chama ProfileStore.Save — esta classe nunca grava por conta própria).
/// Cada componente tem um badge "x" (excluir) no canto, como no editor de referência.
/// </summary>
public sealed class EditorCanvas : FrameLayout
{
    enum DragMode { None, Move, Resize }

    readonly HudProfile profile;
    readonly Action<string> notify;
    readonly Func<bool> save;
    readonly Func<string> freqNote;

    readonly Paint fill = new(PaintFlags.AntiAlias);
    readonly Paint stroke = new(PaintFlags.AntiAlias);
    readonly Paint label = new(PaintFlags.AntiAlias);

    HudComponent? selected;
    ComponentKind? placing;
    DragMode drag = DragMode.None;
    float offX, offY;

    LinearLayout panel = null!;
    TextView title = null!, keyInfo = null!;
    SeekBar opacity = null!;
    Button keyBtn = null!, lockBtn = null!, dupBtn = null!, delBtn = null!, cancelPlaceBtn = null!;
    ViewSettingsPanel? settings;
    bool capturing;
    int captureToken;

    bool EditLocked => profile.View?.LockHudEditing == true;
    float Short => Math.Min(Width, Height);
    float Cx(HudComponent c) => c.RelativeX * Width;
    float Cy(HudComponent c) => c.RelativeY * Height;
    float Radius(HudComponent c) => c.RelativeSize * Short / 2f;
    float HandleX(HudComponent c) => Cx(c) + Radius(c) * 0.7071f;
    float HandleY(HudComponent c) => Cy(c) + Radius(c) * 0.7071f;
    float BadgeX(HudComponent c) => Cx(c) + Radius(c) * 0.7071f;
    float BadgeY(HudComponent c) => Cy(c) - Radius(c) * 0.7071f;
    int Dp(int v) => Ui.Dp(Context!, v);

    public EditorCanvas(Context context, HudProfile profile, Action<string> notify, Func<bool> save, Func<string> freqNote) : base(context)
    {
        this.profile = profile;
        this.notify = notify;
        this.save = save;
        this.freqNote = freqNote;
        SetWillNotDraw(false);
        SetBackgroundColor(Color.Argb(60, 0, 0, 0));
        label.TextAlign = Paint.Align.Center;
        label.Color = Color.White;
        label.TextSize = Dp(11);
        BuildPanel();
    }

    // ---------- painel do componente selecionado ----------
    void BuildPanel()
    {
        panel = new LinearLayout(Context) { Orientation = Orientation.Vertical, Clickable = true };
        panel.Background = Ui.Round(Context!, Palette.Panel, Palette.PinkDark, 12, 1);
        panel.SetPadding(Dp(12), Dp(8), Dp(12), Dp(8));
        panel.Visibility = ViewStates.Gone;

        title = Ui.Label(Context!, "", 14);
        panel.AddView(title);

        var opRow = new LinearLayout(Context) { Orientation = Orientation.Horizontal };
        opRow.AddView(Ui.Label(Context!, "Opacidade", 12, Palette.Muted));
        opacity = new SeekBar(Context) { Max = 90 };   // progresso 0..90 => 10..100 %
        opRow.AddView(opacity, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WrapContent, 1f));
        panel.AddView(opRow);
        opacity.ProgressChanged += (_, e) =>
        {
            if (!e.FromUser || selected == null || selected.Locked || EditLocked) return;
            selected.OpacityPercent = e.Progress + 10;
            Invalidate();
        };
        opacity.StopTrackingTouch += (_, _) => { if (selected != null && !selected.Locked && !EditLocked) save(); };

        keyInfo = Ui.Label(Context!, "", 12, Palette.Muted);
        panel.AddView(keyInfo);

        var row = new LinearLayout(Context) { Orientation = Orientation.Horizontal };
        keyBtn = Ui.Btn(Context!, "Tecla", OnKeyClicked);
        dupBtn = Ui.Btn(Context!, "Duplicar", OnDuplicate);
        delBtn = Ui.Btn(Context!, "Excluir", () => { if (selected != null) DeleteComponent(selected); });
        lockBtn = Ui.Btn(Context!, "Bloquear", OnToggleLock);
        foreach (var b in new[] { keyBtn, dupBtn, delBtn, lockBtn })
            row.AddView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WrapContent, 1f) { LeftMargin = Dp(2), RightMargin = Dp(2) });
        panel.AddView(row);

        AddView(panel, new LayoutParams(ViewGroup.LayoutParams.MatchParent, ViewGroup.LayoutParams.WrapContent, GravityFlags.Bottom)
        { LeftMargin = Dp(60), RightMargin = Dp(60), BottomMargin = Dp(6) });

        cancelPlaceBtn = Ui.Btn(Context!, "Cancelar posicionamento", () => { placing = null; UpdateChrome(); Invalidate(); });
        cancelPlaceBtn.Visibility = ViewStates.Gone;
        AddView(cancelPlaceBtn, new LayoutParams(ViewGroup.LayoutParams.WrapContent, ViewGroup.LayoutParams.WrapContent,
            GravityFlags.Top | GravityFlags.CenterHorizontal) { TopMargin = Dp(70) });
    }

    // ---------- API pública ----------
    public void BeginPlacement(ComponentKind kind)
    {
        CloseSettings();
        CancelCapture();
        placing = kind;
        Select(null);
    }

    public void ToggleSettings()
    {
        if (settings != null) { CloseSettings(); return; }
        placing = null;
        settings = new ViewSettingsPanel(Context!, profile, () => selected, save, freqNote, () => Short,
            Invalidate, DeleteComponent, CloseSettings, notify);
        AddView(settings, new LayoutParams(Dp(280), ViewGroup.LayoutParams.WrapContent, GravityFlags.Center));
        UpdateChrome();
    }

    void CloseSettings()
    {
        if (settings == null) return;
        RemoveView(settings);
        settings = null;
        UpdateChrome();
    }

    // ---------- seleção / painel ----------
    void Select(HudComponent? c)
    {
        CancelCapture();
        selected = c;
        settings?.Build();   // o diálogo mostra tamanho/excluir só com seleção
        UpdateChrome();
        Invalidate();
    }

    void UpdateChrome()
    {
        cancelPlaceBtn.Visibility = placing != null ? ViewStates.Visible : ViewStates.Gone;
        // com o diálogo de Vista aberto, ele já concentra tamanho/excluir: o painel inferior sai da frente
        if (selected == null || placing != null || settings != null) { panel.Visibility = ViewStates.Gone; return; }

        panel.Visibility = ViewStates.Visible;
        var c = selected;
        bool canEdit = !EditLocked && !c.Locked;
        title.Text = c.Kind.Label() + (c.Locked ? "  (bloqueado)" : "") + (EditLocked ? "  — edição bloqueada em Configurações: Vista" : "");
        opacity.Progress = Math.Clamp(c.OpacityPercent, 10, 100) - 10;
        opacity.Enabled = canEdit;

        if (c.Kind.HasSingleKey())
        {
            string what = c.Kind == ComponentKind.View ? "Tecla mostrar/ocultar seta" : "Tecla";
            keyInfo.Text = capturing
                ? "Pressione a tecla desejada… (exige o Serviço de Acessibilidade ativo)"
                : $"{what}: {(string.IsNullOrEmpty(c.KeyLabel) ? "nenhuma" : c.KeyLabel)}";
            keyBtn.Enabled = canEdit || capturing;
            keyBtn.Text = capturing ? "Cancelar" : "Tecla";
        }
        else
        {
            keyInfo.Text = c.Kind.WhyNoSingleKey();
            keyBtn.Enabled = false;
        }
        dupBtn.Enabled = !EditLocked;
        delBtn.Enabled = canEdit;
        lockBtn.Enabled = !EditLocked;
        lockBtn.Text = c.Locked ? "Desbloquear" : "Bloquear";
    }

    // ---------- ações ----------
    void OnKeyClicked()
    {
        if (selected == null) return;
        if (capturing) { CancelCapture(); UpdateChrome(); return; }
        if (selected.Locked || EditLocked) return;

        capturing = true;
        int my = ++captureToken;
        var target = selected;
        InputEventHub.CaptureNextKey((code, lbl) => Post(() =>
        {
            if (!capturing || my != captureToken) return;
            capturing = false;
            target.KeyCode = code;
            target.KeyLabel = lbl;
            UpdateChrome();
            Invalidate();
            save();
        }));
        PostDelayed(() =>
        {
            if (capturing && my == captureToken)
            {
                CancelCapture();
                UpdateChrome();
                notify("Nenhuma tecla recebida. O Serviço de Acessibilidade está ativo?");
            }
        }, 10000);
        UpdateChrome();
    }

    void CancelCapture()
    {
        if (!capturing) return;
        capturing = false;
        captureToken++;
        InputEventHub.CancelCapture();
    }

    void OnDuplicate()
    {
        if (selected == null || EditLocked) return;
        var copy = HudCloner.CloneComponent(selected);
        profile.Components.Add(copy);
        if (!save()) { profile.Components.Remove(copy); return; }
        Select(copy);
    }

    void DeleteComponent(HudComponent c)
    {
        if (c.Locked || EditLocked) return;
        int idx = profile.Components.IndexOf(c);
        if (idx < 0) return;
        profile.Components.Remove(c);
        if (!save()) { profile.Components.Insert(idx, c); return; }
        if (ReferenceEquals(selected, c)) Select(null); else Invalidate();
    }

    void OnToggleLock()
    {
        if (selected == null || EditLocked) return;
        selected.Locked = !selected.Locked;
        save();
        settings?.Build();
        UpdateChrome();
        Invalidate();
    }

    // ---------- toque ----------
    HudComponent? HitTest(float x, float y)
    {
        for (int i = profile.Components.Count - 1; i >= 0; i--)
        {
            var c = profile.Components[i];
            float dx = x - Cx(c), dy = y - Cy(c);
            if (Math.Sqrt(dx * dx + dy * dy) <= Radius(c) + Dp(4)) return c;
        }
        return null;
    }

    HudComponent? HitBadge(float x, float y)
    {
        if (EditLocked) return null;
        for (int i = profile.Components.Count - 1; i >= 0; i--)
        {
            var c = profile.Components[i];
            if (!c.Locked && Dist(x, y, BadgeX(c), BadgeY(c)) < Dp(14)) return c;
        }
        return null;
    }

    static float Dist(float x1, float y1, float x2, float y2) =>
        (float)Math.Sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));

    public override bool OnTouchEvent(MotionEvent? e)
    {
        if (e == null) return false;
        float x = e.GetX(), y = e.GetY();
        switch (e.ActionMasked)
        {
            case MotionEventActions.Down:
                if (placing != null) { Place(x, y); return true; }
                var badge = HitBadge(x, y);
                if (badge != null) { DeleteComponent(badge); drag = DragMode.None; return true; }
                if (selected != null && !selected.Locked && !EditLocked &&
                    Dist(x, y, HandleX(selected), HandleY(selected)) < Dp(22))
                { drag = DragMode.Resize; return true; }
                var hit = HitTest(x, y);
                Select(hit);
                if (hit != null && !hit.Locked && !EditLocked)
                { drag = DragMode.Move; offX = x - Cx(hit); offY = y - Cy(hit); }
                else drag = DragMode.None;
                return true;

            case MotionEventActions.Move:
                if (selected == null || Width == 0) break;
                if (drag == DragMode.Move)
                {
                    selected.RelativeX = Math.Clamp((x - offX) / Width, 0f, 1f);
                    selected.RelativeY = Math.Clamp((y - offY) / Height, 0f, 1f);
                    Invalidate();
                }
                else if (drag == DragMode.Resize)
                {
                    float r = Dist(x, y, Cx(selected), Cy(selected));
                    selected.RelativeSize = Math.Clamp(2f * r / Short, 0.04f, 0.6f);
                    Invalidate();
                }
                return true;

            case MotionEventActions.Up:
            case MotionEventActions.Cancel:
                if (drag != DragMode.None) { save(); settings?.Build(); }   // salva ao soltar; o diálogo reflete o novo tamanho
                drag = DragMode.None;
                return true;
        }
        return base.OnTouchEvent(e);
    }

    void Place(float x, float y)
    {
        var kind = placing!.Value;
        placing = null;
        var c = new HudComponent
        {
            Id = Guid.NewGuid().ToString("N"),
            Kind = kind,
            RelativeX = Math.Clamp(x / Width, 0f, 1f),
            RelativeY = Math.Clamp(y / Height, 0f, 1f),
            RelativeSize = 0.12f,
            OpacityPercent = 70,
            Locked = false
        };
        profile.Components.Add(c);
        if (!save()) { profile.Components.Remove(c); UpdateChrome(); Invalidate(); return; }
        Select(c);
    }

    // ---------- desenho ----------
    protected override void OnDraw(Canvas? canvas)
    {
        base.OnDraw(canvas);
        if (canvas == null) return;

        foreach (var c in profile.Components)
        {
            uint argb = c.Kind.ColorArgb();
            int a = (int)(Math.Clamp(c.OpacityPercent, 10, 100) / 100f * 255f);
            fill.SetStyle(Paint.Style.Fill);
            fill.Color = Color.Argb(a, (int)((argb >> 16) & 0xFF), (int)((argb >> 8) & 0xFF), (int)(argb & 0xFF));
            canvas.DrawCircle(Cx(c), Cy(c), Radius(c), fill);

            stroke.SetStyle(Paint.Style.Stroke);
            bool sel = ReferenceEquals(c, selected);
            stroke.StrokeWidth = sel ? Dp(3) : Dp(2);
            stroke.Color = sel ? Color.Yellow : Palette.Pink;
            canvas.DrawCircle(Cx(c), Cy(c), Radius(c), stroke);

            canvas.DrawText(c.Kind.Label(), Cx(c), Cy(c), label);
            if (c.Kind.HasSingleKey() && !string.IsNullOrEmpty(c.KeyLabel))
                canvas.DrawText(c.KeyLabel!, Cx(c), Cy(c) + label.TextSize * 1.2f, label);
            if (c.Locked)
                canvas.DrawText("[bloqueado]", Cx(c), Cy(c) - label.TextSize * 1.2f, label);

            if (!c.Locked && !EditLocked)
            {
                // badge "x" de excluir
                fill.Color = Palette.PinkDark;
                canvas.DrawCircle(BadgeX(c), BadgeY(c), Dp(9), fill);
                stroke.StrokeWidth = Dp(1);
                stroke.Color = Color.White;
                float k = Dp(3);
                canvas.DrawLine(BadgeX(c) - k, BadgeY(c) - k, BadgeX(c) + k, BadgeY(c) + k, stroke);
                canvas.DrawLine(BadgeX(c) - k, BadgeY(c) + k, BadgeX(c) + k, BadgeY(c) - k, stroke);
            }
            if (sel && !c.Locked && !EditLocked)
            {
                fill.Color = Color.Yellow;
                canvas.DrawCircle(HandleX(c), HandleY(c), Dp(9), fill);
            }
        }

        if (placing != null)
        {
            label.TextSize = Dp(16);
            canvas.DrawText($"Toque na tela para posicionar: {placing.Value.Label()}", Width / 2f, Dp(60), label);
            label.TextSize = Dp(11);
        }
    }

    protected override void OnDetachedFromWindow()
    {
        CancelCapture();
        base.OnDetachedFromWindow();
    }
}
