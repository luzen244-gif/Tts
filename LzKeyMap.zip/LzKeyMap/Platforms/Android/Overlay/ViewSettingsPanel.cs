using Android.Content;
using Android.Views;
using Android.Widget;
using LzKeyMap.Core.Devices;
using LzKeyMap.Core.Models;
using Orientation = Android.Widget.Orientation;

namespace LzKeyMap.Overlay;

/// <summary>
/// Diálogo "Configurações: Vista" desenhado dentro do overlay.
///  - Sensibilidade X/Y (slider + botões ±0,01x) e frequência de saída: são do HUD (ViewSettings), valem para Vista e Tiro.
///  - Tecla de mostrar/ocultar seta: guardada no componente Vista (KeyCode/KeyLabel).
///  - Tamanho em dp e Excluir: só aparecem quando há um componente selecionado.
/// Tudo é gravado via o callback 'save' (ProfileStore.Save) — este painel nunca grava sozinho.
/// </summary>
internal sealed class ViewSettingsPanel : LinearLayout
{
    const double SensMin = 0.01, SensMax = 5.0, SensStep = 0.01;

    readonly HudProfile profile;
    readonly Func<HudComponent?> selected;
    readonly Func<bool> save;
    readonly Func<string> freqNote;
    readonly Func<float> shortSide;
    readonly Action onGeometryChanged;
    readonly Action<HudComponent> onDelete;
    readonly Action onClose;
    readonly Action<string> notify;
    bool capturing;
    int token;

    int Dp(int v) => Ui.Dp(Context!, v);
    ViewSettings V => profile.View ??= ViewSettings.Defaults();
    bool HudLocked => V.LockHudEditing;

    public ViewSettingsPanel(Context ctx, HudProfile profile, Func<HudComponent?> selected, Func<bool> save, Func<string> freqNote,
        Func<float> shortSide, Action onGeometryChanged, Action<HudComponent> onDelete, Action onClose, Action<string> notify) : base(ctx)
    {
        this.profile = profile; this.selected = selected; this.save = save; this.freqNote = freqNote;
        this.shortSide = shortSide; this.onGeometryChanged = onGeometryChanged; this.onDelete = onDelete;
        this.onClose = onClose; this.notify = notify;
        Orientation = Orientation.Vertical;
        Clickable = true;   // não deixa o toque "vazar" para o canvas por baixo
        Background = Ui.Round(ctx, Palette.Panel, Palette.PinkDark, 14, 1);
        SetPadding(Dp(12), Dp(10), Dp(12), Dp(12));
        Build();
    }

    static string Fmt(string name, double v) => $"{name}: {v.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture).Replace('.', ',')}x";

    LayoutParams Wrap(int top = 0) =>
        new(ViewGroup.LayoutParams.MatchParent, ViewGroup.LayoutParams.WrapContent) { TopMargin = Dp(top) };

    public void Build()
    {
        RemoveAllViews();

        var head = new LinearLayout(Context) { Orientation = Orientation.Horizontal };
        var title = Ui.Label(Context!, "Configurações: Vista", 14);
        head.AddView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WrapContent, 1f));
        head.AddView(Ui.Btn(Context!, "✕", onClose, size: 13));
        AddView(head, Wrap());

        AddAxis("Sensibilidade X (horizontal)", () => V.SensitivityX, v => V.SensitivityX = v);
        AddAxis("Sensibilidade Y (vertical)", () => V.SensitivityY, v => V.SensitivityY = v);

        AddView(Ui.Label(Context!, "Frequência de saída (Vista + Tiro)"), Wrap(10));
        var all = Enum.GetValues<OutputFrequencyHz>();
        for (int i = 0; i < all.Length; i += 3)
        {
            var row = new LinearLayout(Context) { Orientation = Orientation.Horizontal };
            for (int j = i; j < Math.Min(i + 3, all.Length); j++)
            {
                var hz = all[j];
                bool on = V.Frequency.Equals(hz);
                var b = Ui.Btn(Context!, (on ? "✓ " : "") + $"{Convert.ToInt32(hz)} Hz", () => { V.Frequency = hz; save(); Build(); }, primary: on);
                row.AddView(b, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WrapContent, 1f) { LeftMargin = Dp(2), RightMargin = Dp(2), TopMargin = Dp(4) });
            }
            AddView(row, Wrap());
        }
        // nunca esconde a diferença entre o Hz pedido e o que o método de execução sustenta
        AddView(Ui.Label(Context!, freqNote(), 10, Palette.Amber), Wrap(4));

        var keyTarget = selected() is { Kind: ComponentKind.View } s ? s : profile.Components.FirstOrDefault(c => c.Kind == ComponentKind.View);
        if (keyTarget != null) AddKeyRow(keyTarget);

        var sel = selected();
        if (sel != null)
        {
            bool canEdit = !HudLocked && !sel.Locked;
            float density = Context!.Resources!.DisplayMetrics!.Density;
            int dpNow = (int)Math.Round(sel.RelativeSize * shortSide() / density);
            var sizeLbl = Ui.Label(Context!, $"Tamanho / diâmetro no HUD: {dpNow} dp");
            AddView(sizeLbl, Wrap(10));
            var sb = new SeekBar(Context) { Max = 130, Enabled = canEdit };   // 20..150 dp
            sb.Progress = Math.Clamp(dpNow - 20, 0, 130);
            sb.ProgressChanged += (_, e) =>
            {
                if (!e.FromUser || !canEdit) return;
                int dp = 20 + e.Progress;
                sel.RelativeSize = Math.Clamp(dp * density / Math.Max(shortSide(), 1f), 0.04f, 0.6f);
                sizeLbl.Text = $"Tamanho / diâmetro no HUD: {dp} dp";
                onGeometryChanged();
            };
            sb.StopTrackingTouch += (_, _) => { if (canEdit) save(); };
            AddView(sb, Wrap());

            var del = Ui.Btn(Context!, "✕ Excluir componente", () => onDelete(sel), primary: true, size: 12);
            del.Enabled = canEdit;
            AddView(del, Wrap(8));
        }
    }

    void AddAxis(string name, Func<double> get, Action<double> set)
    {
        var lbl = Ui.Label(Context!, Fmt(name, get()));
        AddView(lbl, Wrap(8));
        var sb = new SeekBar(Context) { Max = 499 };   // 0,01 .. 5,00
        sb.Progress = Math.Clamp((int)Math.Round(get() * 100) - 1, 0, 499);
        sb.ProgressChanged += (_, e) =>
        {
            if (!e.FromUser) return;
            set((e.Progress + 1) / 100.0);
            lbl.Text = Fmt(name, get());
        };
        sb.StopTrackingTouch += (_, _) => save();
        AddView(sb, Wrap());

        void Step(double d)
        {
            double nv = Math.Round(Math.Clamp(get() + d, SensMin, SensMax), 2);
            set(nv);
            sb.Progress = Math.Clamp((int)Math.Round(nv * 100) - 1, 0, 499);
            lbl.Text = Fmt(name, nv);
            save();
        }
        var row = new LinearLayout(Context) { Orientation = Orientation.Horizontal };
        row.AddView(Ui.Btn(Context!, "−0,01x", () => Step(-SensStep)), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WrapContent, 1f) { RightMargin = Dp(4) });
        row.AddView(Ui.Btn(Context!, "+0,01x", () => Step(+SensStep)), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WrapContent, 1f) { LeftMargin = Dp(4) });
        AddView(row, Wrap(2));
    }

    void AddKeyRow(HudComponent target)
    {
        bool canEdit = !HudLocked && !target.Locked;
        var row = new LinearLayout(Context) { Orientation = Orientation.Horizontal };
        row.SetGravity(GravityFlags.CenterVertical);
        row.AddView(Ui.Label(Context!, "Mostrar / ocultar seta"), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WrapContent, 1f));
        var keyBox = Ui.Btn(Context!, capturing ? "…" : (string.IsNullOrEmpty(target.KeyLabel) ? "—" : target.KeyLabel!), () => { });
        keyBox.Enabled = false;
        row.AddView(keyBox, new LinearLayout.LayoutParams(Dp(54), ViewGroup.LayoutParams.WrapContent) { RightMargin = Dp(4) });
        var pick = Ui.Btn(Context!, capturing ? "Cancelar" : "Selecionar", () =>
        {
            if (capturing) { Cancel(); Build(); return; }
            capturing = true;
            int my = ++token;
            InputEventHub.CaptureNextKey((code, lbl) => Post(() =>
            {
                if (!capturing || my != token) return;
                capturing = false;
                target.KeyCode = code; target.KeyLabel = lbl;
                save();
                Build();
            }));
            PostDelayed(() =>
            {
                if (capturing && my == token) { Cancel(); Build(); notify("Nenhuma tecla recebida. O Serviço de Acessibilidade está ativo?"); }
            }, 10000);
            Build();
        }, primary: true);
        pick.Enabled = canEdit || capturing;
        row.AddView(pick, new LinearLayout.LayoutParams(Dp(92), ViewGroup.LayoutParams.WrapContent));
        AddView(row, Wrap(10));
        AddView(Ui.Label(Context!, "A tecla fica salva no HUD. O desenho/alternância da seta pelo motor ainda não foi implementado.", 10, Palette.Muted), Wrap(2));
    }

    void Cancel()
    {
        if (!capturing) return;
        capturing = false; token++;
        InputEventHub.CancelCapture();
    }

    protected override void OnDetachedFromWindow()
    {
        Cancel();
        base.OnDetachedFromWindow();
    }
}
