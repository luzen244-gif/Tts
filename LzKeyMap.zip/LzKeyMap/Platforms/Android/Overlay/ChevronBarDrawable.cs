using Android.Graphics;
using Android.Graphics.Drawables;
using Color = Android.Graphics.Color;
using Paint = Android.Graphics.Paint;
using Path = Android.Graphics.Path;

namespace LzKeyMap.Overlay;

/// <summary>Fundo da barra: hexágono alongado (pontas em chevron) escuro com contorno rosa.</summary>
internal sealed class ChevronBarDrawable : Drawable
{
    readonly Paint fill = new(PaintFlags.AntiAlias);
    readonly Paint stroke = new(PaintFlags.AntiAlias);
    readonly Path path = new();
    readonly float tip;

    public ChevronBarDrawable(float tipPx, float strokePx)
    {
        tip = tipPx;
        fill.SetStyle(Paint.Style.Fill);
        fill.Color = Color.ParseColor("#F00B0610");
        stroke.SetStyle(Paint.Style.Stroke);
        stroke.StrokeWidth = strokePx;
        stroke.Color = Palette.Pink;
        stroke.StrokeJoin = Paint.Join.Round;
    }

    public override void Draw(Canvas canvas)
    {
        var b = Bounds;
        float inset = stroke.StrokeWidth / 2f;
        float l = b.Left + inset, t = b.Top + inset, r = b.Right - inset, bt = b.Bottom - inset;
        float mid = (t + bt) / 2f;
        path.Reset();
        path.MoveTo(l, mid);
        path.LineTo(l + tip, t);
        path.LineTo(r - tip, t);
        path.LineTo(r, mid);
        path.LineTo(r - tip, bt);
        path.LineTo(l + tip, bt);
        path.Close();
        canvas.DrawPath(path, fill);
        canvas.DrawPath(path, stroke);
    }

    public override void SetAlpha(int alpha) { fill.Alpha = alpha; stroke.Alpha = alpha; }
    public override void SetColorFilter(ColorFilter? colorFilter) { fill.SetColorFilter(colorFilter); stroke.SetColorFilter(colorFilter); }
    public override int Opacity => (int)Format.Translucent;
}
