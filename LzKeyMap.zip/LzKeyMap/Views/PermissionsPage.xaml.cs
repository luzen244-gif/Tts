using LzKeyMap.ViewModels;

namespace LzKeyMap.Views;

public partial class PermissionsPage : ContentPage
{
    readonly PermissionsViewModel vm;

    public PermissionsPage(PermissionsViewModel vm)
    {
        InitializeComponent();
        BindingContext = this.vm = vm;
    }

    protected override void OnAppearing() { base.OnAppearing(); vm.Start(); }
    protected override void OnDisappearing() { vm.Stop(); base.OnDisappearing(); }
}
