using LzKeyMap.ViewModels;

namespace LzKeyMap.Views;

public partial class DevicesPage : ContentPage
{
    readonly DevicesViewModel vm;

    public DevicesPage(DevicesViewModel vm)
    {
        InitializeComponent();
        BindingContext = this.vm = vm;
    }

    protected override void OnAppearing() { base.OnAppearing(); vm.Start(); }
    protected override void OnDisappearing() { vm.Stop(); base.OnDisappearing(); }
}
