using LzKeyMap.ViewModels;

namespace LzKeyMap.Views;

public partial class AppPickerPage : ContentPage
{
    readonly AppPickerViewModel vm;

    public AppPickerPage(AppPickerViewModel vm)
    {
        InitializeComponent();
        BindingContext = this.vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await vm.LoadAsync();
    }
}
