using LzKeyMap.ViewModels;

namespace LzKeyMap.Views;

public partial class HomePage : ContentPage
{
    readonly HomeViewModel vm;

    public HomePage(HomeViewModel vm)
    {
        InitializeComponent();
        BindingContext = this.vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await vm.LoadAsync();
    }
}
