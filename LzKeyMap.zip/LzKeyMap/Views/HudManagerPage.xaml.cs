using LzKeyMap.ViewModels;

namespace LzKeyMap.Views;

public partial class HudManagerPage : ContentPage
{
    readonly HudManagerViewModel vm;

    public HudManagerPage(HudManagerViewModel vm)
    {
        InitializeComponent();
        BindingContext = this.vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await vm.LoadAsync();   // volta do "+ APP" com a lista atualizada
    }
}
