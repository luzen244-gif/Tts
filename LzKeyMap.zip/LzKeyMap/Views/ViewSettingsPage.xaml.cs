using LzKeyMap.ViewModels;

namespace LzKeyMap.Views;

public partial class ViewSettingsPage : ContentPage
{
    readonly ViewSettingsViewModel vm;

    public ViewSettingsPage(ViewSettingsViewModel vm)
    {
        InitializeComponent();
        BindingContext = this.vm = vm;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        vm.Load();   // recarrega o HUD ativo e o limite real do método de execução
    }
}
