LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE    := evdev_reader
LOCAL_SRC_FILES := evdev_reader.cpp
LOCAL_CPPFLAGS  := -std=c++17 -O2 -Wall -Wextra
include $(BUILD_EXECUTABLE)
