// evdev_reader — lê mouses em /dev/input/event* (precisa de root) e imprime eventos em texto no stdout:
//   READY n         n mouses abertos
//   ERR texto       falha fatal (o processo sai com código != 0)
//   B código 0|1    botão (BTN_*, valor evdev) solto/pressionado
//   M dx dy         movimento acumulado entre dois SYN_REPORT
//
// Uso:  evdev_reader [--grab] [--device ARQUIVO]
//   --grab    EVIOCGRAB: o mouse passa a ser exclusivo deste processo (o Android para de usá-lo).
//             O kernel devolve o mouse ao sistema quando o processo termina.
//   --device  lê eventos de ARQUIVO (um nó evdev ou um arquivo de struct input_event) sem detecção de mouse.
//             Serve para testar o parser sem hardware.
// Termina quando o stdin fecha (o app fechou/morreu) ou quando o stdout quebra (SIGPIPE).

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

namespace {

constexpr int kMaxDevices = 16;

struct Dev {
    int fd = -1;
    char path[300] = {0};
};

Dev devs[kMaxDevices];
int ndevs = 0;
bool grab = false;
const char* forced_device = nullptr;

inline bool test_bit(int bit, const unsigned char* arr) { return arr[bit / 8] & (1 << (bit % 8)); }

bool already_open(const char* path) {
    for (int i = 0; i < ndevs; i++)
        if (strcmp(devs[i].path, path) == 0) return true;
    return false;
}

bool is_mouse(int fd) {
    unsigned char ev[(EV_MAX + 8) / 8] = {0};
    unsigned char rel[(REL_MAX + 8) / 8] = {0};
    unsigned char key[(KEY_MAX + 8) / 8] = {0};
    if (ioctl(fd, EVIOCGBIT(0, sizeof(ev)), ev) < 0) return false;
    if (!test_bit(EV_REL, ev) || !test_bit(EV_KEY, ev)) return false;
    if (ioctl(fd, EVIOCGBIT(EV_REL, sizeof(rel)), rel) < 0) return false;
    if (ioctl(fd, EVIOCGBIT(EV_KEY, sizeof(key)), key) < 0) return false;
    return test_bit(REL_X, rel) && test_bit(REL_Y, rel) && test_bit(BTN_LEFT, key);
}

void add_device(const char* path, bool skip_check) {
    if (ndevs >= kMaxDevices || already_open(path)) return;
    int fd = open(path, O_RDONLY | O_NONBLOCK | O_CLOEXEC);
    if (fd < 0) return;
    if (!skip_check && !is_mouse(fd)) { close(fd); return; }
    if (grab && !skip_check && ioctl(fd, EVIOCGRAB, 1) < 0) { close(fd); return; }
    devs[ndevs].fd = fd;
    snprintf(devs[ndevs].path, sizeof(devs[ndevs].path), "%s", path);
    ndevs++;
}

void scan() {
    DIR* d = opendir("/dev/input");
    if (!d) return;
    while (dirent* e = readdir(d)) {
        if (strncmp(e->d_name, "event", 5) != 0) continue;
        char path[300];
        snprintf(path, sizeof(path), "/dev/input/%s", e->d_name);
        add_device(path, false);
    }
    closedir(d);
}

void drop(int i) {
    close(devs[i].fd);
    devs[i] = devs[ndevs - 1];
    devs[ndevs - 1] = Dev();
    ndevs--;
}

long acc_x = 0, acc_y = 0;

void handle(const input_event& e) {
    if (e.type == EV_REL) {
        if (e.code == REL_X) acc_x += e.value;
        else if (e.code == REL_Y) acc_y += e.value;
    } else if (e.type == EV_KEY) {
        if (e.code >= BTN_MOUSE && e.code <= BTN_TASK && (e.value == 0 || e.value == 1)) {
            printf("B %d %d\n", (int)e.code, (int)e.value);
            fflush(stdout);
        }
    } else if (e.type == EV_SYN && e.code == SYN_REPORT) {
        if (acc_x != 0 || acc_y != 0) {
            printf("M %ld %ld\n", acc_x, acc_y);
            fflush(stdout);
            acc_x = acc_y = 0;
        }
    }
}

}  // namespace

int main(int argc, char** argv) {
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--grab") == 0) grab = true;
        else if (strcmp(argv[i], "--device") == 0 && i + 1 < argc) forced_device = argv[++i];
    }
    signal(SIGPIPE, SIG_DFL);   // stdout fechado = o app não quer mais: sai

    if (forced_device) add_device(forced_device, true);
    else scan();

    if (ndevs == 0) {
        printf("ERR nenhum mouse encontrado em /dev/input (sem root, ou nenhum mouse conectado)\n");
        fflush(stdout);
        return 2;
    }
    printf("READY %d\n", ndevs);
    fflush(stdout);

    for (;;) {
        pollfd fds[kMaxDevices + 1];
        fds[0] = {0, POLLIN, 0};
        for (int i = 0; i < ndevs; i++) fds[i + 1] = {devs[i].fd, POLLIN, 0};

        int r = poll(fds, ndevs + 1, forced_device ? 100 : 2000);
        if (r < 0) {
            if (errno == EINTR) continue;
            printf("ERR poll falhou: %s\n", strerror(errno));
            return 3;
        }
        if (r == 0) {
            if (forced_device) return 0;   // modo teste: acabou
            scan();                          // mouse espetado depois de iniciar
            continue;
        }

        if (fds[0].revents & (POLLIN | POLLHUP | POLLERR)) {
            char buf[64];
            ssize_t n = read(0, buf, sizeof(buf));
            if (n == 0 || (n < 0 && errno != EAGAIN && errno != EINTR)) return 0;   // stdin fechou
        }

        for (int i = ndevs - 1; i >= 0; i--) {
            if (!(fds[i + 1].revents & (POLLIN | POLLHUP | POLLERR))) continue;
            input_event evs[64];
            ssize_t n = read(devs[i].fd, evs, sizeof(evs));
            if (n <= 0) {
                if (n < 0 && (errno == EAGAIN || errno == EINTR)) continue;
                drop(i);   // dispositivo removido (ou fim do arquivo no modo teste)
                if (ndevs == 0 && forced_device) return 0;
                continue;
            }
            for (ssize_t k = 0; k < n / (ssize_t)sizeof(input_event); k++) handle(evs[k]);
        }
    }
}
