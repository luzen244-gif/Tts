# evdev_reader (nativo, C++)

Lê o(s) mouse(s) de `/dev/input/event*` como root e imprime `READY n`, `ERR texto`, `B código 0|1` e `M dx dy`
(ver o cabeçalho de `jni/evdev_reader.cpp`). Com `--grab` o mouse fica exclusivo do mapeamento.

## Compilar (precisa do Android NDK)
```
cd native
ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=jni/Android.mk NDK_APPLICATION_MK=jni/Application.mk
```
O binário sai em `libs/arm64-v8a/evdev_reader` (e `armeabi-v7a`). Copie o do ABI do seu aparelho (quase sempre arm64-v8a)
por cima de `Resources/Raw/evdev_reader`. Enquanto esse arquivo for o placeholder de texto, o app avisa que o
leitor de mouse não está compilado.

## Testado
O parser foi compilado com g++ no Linux e alimentado com eventos sintéticos (`--device arquivo`): soma de movimento por
SYN_REPORT, botões 0/1, auto-repeat ignorado, teclas fora de BTN_MOUSE..BTN_TASK ignoradas, `ERR` + código 2 sem mouse.
NÃO foi testado em aparelho real nem com `--grab`.
