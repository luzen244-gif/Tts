using System.Diagnostics;
using System.Text;
using LzKeyMap.Core.Models;
using LzKeyMap.Services;

namespace LzKeyMap.Core.Devices;

/// <summary>
/// Captura de MOUSE via Root: roda o binário nativo evdev_reader (C++, native/jni) como root e lê o que ele imprime:
///   READY n        — n mouses abertos
///   ERR texto      — falha (sem mouse, sem permissão...)
///   B código 0|1   — botão (BTN_* do evdev) solto/pressionado
///   M dx dy        — movimento acumulado entre dois SYN_REPORT
/// Com grab=true o reader toma o mouse com exclusividade (EVIOCGRAB): o Android deixa de mover o cursor/clicar,
/// e SÓ o mapeamento recebe o mouse. Ao parar (ou se o app morrer) o kernel devolve o mouse ao sistema.
/// O arquivo Resources/Raw/evdev_reader no repositório é um PLACEHOLDER até você compilar com o NDK.
/// </summary>
public sealed class RawInputService
{
    public static RawInputService Instance { get; } = new();

    const string AssetName = "evdev_reader";
    const string RemotePath = "/data/local/tmp/lz_evdev_reader";

    readonly object gate = new();
    Process? proc;
    Thread? reader;
    volatile bool running;
    ManualResetEventSlim? ready;
    string startMessage = "";
    bool startOk;

    public bool IsRunning => running;

    public (bool Ok, string Message) Start(bool grab)
    {
        lock (gate)
        {
            if (running) return (true, "Leitor de mouse já ativo.");

            var ctx = Android.App.Application.Context;
            var local = Path.Combine(ctx.FilesDir!.AbsolutePath, AssetName);
            try
            {
                using var asset = ctx.Assets!.Open(AssetName);
                using var ms = new MemoryStream();
                asset.CopyTo(ms);
                var bytes = ms.ToArray();
                if (bytes.Length < 64 || Encoding.ASCII.GetString(bytes, 0, Math.Min(11, bytes.Length)) == "PLACEHOLDER")
                    return (false, "o binário nativo evdev_reader ainda é o placeholder — compile native/jni com o NDK (native/README.md).");
                File.WriteAllBytes(local, bytes);
            }
            catch (Exception ex)
            {
                return (false, "não consegui preparar o evdev_reader: " + ex.Message);
            }

            try
            {
                proc = Process.Start(new ProcessStartInfo("su")
                {
                    RedirectStandardInput = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false
                })!;
            }
            catch (Exception ex)
            {
                return (false, "su indisponível: " + ex.Message);
            }

            ready = new ManualResetEventSlim(false);
            startOk = false; startMessage = "";
            running = true;
            reader = new Thread(ReadLoop) { IsBackground = true, Name = "lz-evdev" };
            reader.Start();

            // root copia o binário para um lugar executável e o executa no lugar do shell
            var w = proc.StandardInput;
            w.WriteLine($"cp '{local}' {RemotePath} && chmod 755 {RemotePath}");
            w.WriteLine($"exec {RemotePath}{(grab ? " --grab" : "")}");
            w.Flush();

            if (!ready.Wait(4000))
            {
                StopLocked();
                return (false, "o evdev_reader não respondeu em 4 s (root negado ou binário incompatível com a arquitetura).");
            }
            if (!startOk) { var m = startMessage; StopLocked(); return (false, m); }
            return (true, startMessage);
        }
    }

    public void Stop()
    {
        lock (gate) StopLocked();
    }

    void StopLocked()
    {
        running = false;
        try { proc?.StandardInput.Close(); } catch { }   // o reader sai ao ver EOF no stdin
        try { if (proc != null && !proc.WaitForExit(500)) proc.Kill(); } catch { }
        proc = null;
        ready?.Set();
    }

    void ReadLoop()
    {
        var p = proc;
        if (p == null) return;
        try
        {
            string? line;
            while (running && (line = p.StandardOutput.ReadLine()) != null)
                HandleLine(line);
        }
        catch (Exception) { }
        finally
        {
            if (running) { running = false; }   // o processo morreu sozinho
            ready?.Set();
        }
    }

    void HandleLine(string line)
    {
        if (line.StartsWith("READY"))
        {
            startOk = true; startMessage = "Mouse capturado via Root (" + line[5..].Trim() + " dispositivo(s)).";
            ready?.Set();
        }
        else if (line.StartsWith("ERR"))
        {
            startOk = false; startMessage = line[3..].Trim();
            ready?.Set();
        }
        else if (line.StartsWith("B "))
        {
            var t = line.Split(' ');
            if (t.Length == 3 && int.TryParse(t[1], out var code) && int.TryParse(t[2], out var val))
            {
                bool down = val != 0;
                bool suppress = InputEventHub.SuppressEngine;
                InputEventHub.PublishMouseButton(InputCodes.MouseBase + code, InputCodes.MouseLabel(code), down);
                if (!suppress) MappingForegroundService.Engine?.OnMouseButton(code, down);
            }
        }
        else if (line.StartsWith("M "))
        {
            var t = line.Split(' ');
            if (t.Length == 3 &&
                float.TryParse(t[1], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var dx) &&
                float.TryParse(t[2], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var dy))
            {
                bool suppress = InputEventHub.SuppressEngine;
                InputEventHub.PublishMouseMove(dx, dy);
                if (!suppress) MappingForegroundService.Engine?.OnMouseMove(dx, dy);
            }
        }
    }
}
