namespace LzKeyMap.Core.Devices;

public enum InputEventKind { Key, MouseButton, MouseMove }

public sealed record RawInputEvent(
    InputEventKind Kind, DateTime Time, string Description, int Code, float Dx, float Dy, bool Down);

/// <summary>
/// Barramento de eventos brutos de entrada, SEPARADO do MappingEngine.
/// Quem captura (LzKeyMapAccessibilityService.OnKeyEvent, RawInputService) apenas publica aqui;
/// as telas de Dispositivos/Teste e o seletor de tecla do editor assinam.
/// </summary>
public static class InputEventHub
{
    static readonly object Gate = new();
    static readonly HashSet<int> keysSeen = new();
    static readonly HashSet<int> mouseButtonsSeen = new();
    static Action<int, string>? captureCallback;

    public static event Action<RawInputEvent>? EventReceived;

    public static long TotalEvents { get; private set; }
    public static int DistinctKeys { get { lock (Gate) return keysSeen.Count; } }
    public static int DistinctMouseButtons { get { lock (Gate) return mouseButtonsSeen.Count; } }

    /// <summary>Modo "TESTAR DISPOSITIVO": o motor NÃO deve despachar toques.</summary>
    public static volatile bool TestMode;

    public static bool IsCapturingKey { get { lock (Gate) return captureCallback != null; } }

    /// <summary>True quando o motor deve ignorar/consumir o evento (teste ou captura de tecla).</summary>
    public static bool SuppressEngine => TestMode || IsCapturingKey;

    public static void ResetCounters()
    {
        lock (Gate) { TotalEvents = 0; keysSeen.Clear(); mouseButtonsSeen.Clear(); }
    }

    /// <summary>Próxima tecla pressionada (down) vai para o callback, uma única vez.</summary>
    public static void CaptureNextKey(Action<int, string> onKey)
    {
        lock (Gate) captureCallback = onKey;
    }

    public static void CancelCapture()
    {
        lock (Gate) captureCallback = null;
    }

    public static void PublishKey(int keyCode, string label, bool down)
    {
        Action<int, string>? cb = null;
        lock (Gate)
        {
            TotalEvents++;
            keysSeen.Add(keyCode);
            if (down && captureCallback != null) { cb = captureCallback; captureCallback = null; }
        }
        cb?.Invoke(keyCode, label);
        EventReceived?.Invoke(new RawInputEvent(InputEventKind.Key, DateTime.Now, label, keyCode, 0, 0, down));
    }

    public static void PublishMouseButton(int button, string label, bool down)
    {
        Action<int, string>? cb = null;
        lock (Gate)
        {
            TotalEvents++;
            mouseButtonsSeen.Add(button);
            // botões do mouse também podem ser atribuídos no editor (o código já vem com InputCodes.MouseBase)
            if (down && captureCallback != null) { cb = captureCallback; captureCallback = null; }
        }
        cb?.Invoke(button, label);
        EventReceived?.Invoke(new RawInputEvent(InputEventKind.MouseButton, DateTime.Now, label, button, 0, 0, down));
    }

    public static void PublishMouseMove(float dx, float dy)
    {
        lock (Gate) TotalEvents++;
        EventReceived?.Invoke(new RawInputEvent(InputEventKind.MouseMove, DateTime.Now, "move", 0, dx, dy, false));
    }
}
