using Android.Content;
using Android.Hardware.Input;
using Android.OS;
using Android.Views;

namespace LzKeyMap.Core.Devices;

public sealed record DetectedDevice(string Name, string Kind /* "keyboard" | "mouse" */, string Connection, string State);

/// <summary>Teclados e mouses conectados, pelo InputManager real do Android.</summary>
public sealed class DeviceManager
{
    public IReadOnlyList<DetectedDevice> GetDevices()
    {
        var result = new List<DetectedDevice>();
        var ctx = Android.App.Application.Context;
        var ids = InputDevice.GetDeviceIds();
        if (ids == null) return result;

        foreach (var id in ids)
        {
            var d = InputDevice.GetDevice(id);
            if (d == null || d.IsVirtual) continue;

            string conn = "Desconhecida";
            if (Build.VERSION.SdkInt >= BuildVersionCodes.R)
                conn = d.IsExternal ? "Externa (USB/Bluetooth)" : "Interna";

            bool mouse = d.SupportsSource(InputSourceType.Mouse) || d.SupportsSource(InputSourceType.MouseRelative);
            bool keyboard = d.KeyboardType == InputKeyboardType.Alphabetic && d.SupportsSource(InputSourceType.Keyboard);

            if (mouse) result.Add(new DetectedDevice(d.Name ?? "Mouse", "mouse", conn, "Conectado"));
            if (keyboard) result.Add(new DetectedDevice(d.Name ?? "Teclado", "keyboard", conn, "Conectado"));
        }
        return result;
    }
}
