using System.Net.Sockets;
using System.Text;
using LzKeyMap.Core.Execution.Adb;

namespace LzKeyMap.Core.Execution;

/// <summary>
/// ADB via cliente próprio (Core/Execution/Adb). Fala com o adbd em 127.0.0.1:Port por TCP SIMPLES.
///
/// O QUE FUNCIONA: autenticação RSA (o aparelho mostra "Permitir depuração USB?" na 1ª vez), shell persistente,
///                 mesmos comandos `input` do Root.
/// O QUE NÃO FUNCIONA (e é dito na UI): o pareamento do "Depuração sem fio" do Android 11+ (código de 6 dígitos,
///   SPAKE2 + TLS 1.3) NÃO está implementado. O ADB só é Available se já houver um adbd em TCP simples na
///   porta configurada (ex.: `adb tcpip 5555` rodado uma vez a partir de um PC; reinicia a cada boot).
/// Status: escrito sem poder compilar/testar aqui — só vira Available depois de uma conexão e um `input` reais.
/// </summary>
public sealed class AdbInputExecutor : ShellInputExecutorBase
{
    public static string Host { get; set; } = "127.0.0.1";
    public static int Port { get; set; } = 5555;

    public override string Name => "ADB";

    AdbKey? key;
    AdbConnection? conn;
    AdbStream? shell;
    readonly object connGate = new();

    static string KeyDir => Path.Combine(Android.App.Application.Context.FilesDir!.AbsolutePath, "adb");

    protected override ExecutorStatus Probe()
    {
        lock (connGate)
        {
            try
            {
                Ensure(connectMs: 1500, authMs: 4000);
                var output = conn!.Exec(ProbeCommand, 4000);
                return InterpretInputHelp(output) ?? Ok();
            }
            catch (AdbAuthPendingException)
            {
                Reset();
                return new ExecutorStatus(ExecutorAvailability.NeedsUserAction,
                    "ADB: aceite o diálogo \"Permitir depuração USB?\" no aparelho (marque \"sempre permitir\") e volte a esta tela.");
            }
            catch (Exception ex) when (ex is SocketException or TimeoutException or AggregateException or IOException)
            {
                Reset();
                return new ExecutorStatus(ExecutorAvailability.NeedsUserAction,
                    $"ADB: nenhum adbd respondeu em {Host}:{Port}. Habilite o ADB em TCP (`adb tcpip {Port}` a partir de um PC, uma vez por boot). " +
                    "O pareamento do Depuração Sem Fio (Android 11+) AINDA NÃO é suportado pelo app.");
            }
        }
    }

    void Ensure(int connectMs, int authMs)
    {
        if (conn is { Alive: true } && shell is { Closed: false }) return;
        Reset();
        key ??= AdbKey.LoadOrCreate(KeyDir);
        conn = AdbConnection.Connect(Host, Port, key, connectMs, authMs);
        shell = conn.Open("shell:", discard: true);
    }

    void Reset()
    {
        conn?.Dispose();
        conn = null; shell = null;
    }

    protected override bool WriteLine(string command)
    {
        lock (connGate)
        {
            try
            {
                Ensure(connectMs: 1500, authMs: 1000);
                conn!.Write(shell!, Encoding.UTF8.GetBytes(command + "\n"));
                return true;
            }
            catch (Exception)
            {
                Reset();
                return false;
            }
        }
    }

    public override void ReleaseAll()
    {
        base.ReleaseAll();
        lock (connGate) Reset();
    }
}
