using System.Text;
using Java.Lang;
using Java.Lang.Reflect;

namespace LzKeyMap.Core.Execution;

/// <summary>
/// Shizuku via REFLEXÃO sobre as classes Java da lib (rikka.shizuku.Shizuku), sem binding C# gerado.
/// Por que reflexão: desde a API 13 `Shizuku.newProcess` é privado e o caminho "oficial" é um UserService com AIDL,
/// que exigiria um Java Binding Library com serviço próprio. A reflexão no método privado é o atalho conhecido.
///
/// REQUISITOS (não verificáveis aqui — sem rede/SDK): incluir api-*.aar e provider-*.aar no APK como
/// AndroidLibrary Bind="false" e declarar rikka.shizuku.ShizukuProvider no manifest (ver README, seção Shizuku).
/// Sem a lib no APK -> Unsupported com a explicação. Só vira Available depois de: binder vivo + permissão
/// concedida + um shell remoto que realmente respondeu ao `input`.
/// </summary>
public sealed class ShizukuInputExecutor : ShellInputExecutorBase
{
    public override string Name => "Shizuku";

    const int RequestCode = 4201;
    static bool requestedOnce;

    Java.Lang.Process? shell;
    Java.IO.OutputStream? stdin;
    readonly object gate = new();

    static Class? ShizukuClass()
    {
        try { return Class.ForName("rikka.shizuku.Shizuku"); }
        catch (ClassNotFoundException) { return null; }
    }

    static Java.Lang.Object? Static(Class cls, string name, Class[]? types = null, params Java.Lang.Object?[] args)
    {
        var m = cls.GetMethod(name, types ?? System.Array.Empty<Class>());
        return m.Invoke(null, args);
    }

    static Java.Lang.Process NewProcess(Class cls, params string[] cmd)
    {
        var stringCls = Class.FromType(typeof(Java.Lang.String));
        var arr = Java.Lang.Reflect.Array.NewInstance(stringCls, cmd.Length);
        for (int i = 0; i < cmd.Length; i++) Java.Lang.Reflect.Array.Set(arr, i, new Java.Lang.String(cmd[i]));
        var arrCls = Class.ForName("[Ljava.lang.String;");
        var m = cls.GetDeclaredMethod("newProcess", arrCls, arrCls, stringCls);
        m.Accessible = true;
        var result = m.Invoke(null, arr, null, null);
        return result.JavaCast<Java.Lang.Process>();
    }

    protected override ExecutorStatus Probe()
    {
        var cls = ShizukuClass();
        if (cls == null)
            return new ExecutorStatus(ExecutorAvailability.Unsupported,
                "Shizuku: a biblioteca (rikka.shizuku api + provider .aar) não está incluída neste build. Adicione-a ao projeto (ver README, seção Shizuku).");
        try
        {
            bool ping = Static(cls, "pingBinder")!.JavaCast<Java.Lang.Boolean>().BooleanValue();
            if (!ping)
                return new ExecutorStatus(ExecutorAvailability.NeedsUserAction,
                    "Shizuku: o serviço não está rodando. Abra o app Shizuku e inicie-o (por Depuração sem fio ou root).");

            int perm = Static(cls, "checkSelfPermission")!.JavaCast<Java.Lang.Integer>().IntValue();
            if (perm != 0)
            {
                if (!requestedOnce)
                {
                    requestedOnce = true;
                    Static(cls, "requestPermission", new[] { Java.Lang.Integer.Type! }, new Java.Lang.Integer(RequestCode));   // Integer.TYPE já é o Class do primitivo int
                }
                return new ExecutorStatus(ExecutorAvailability.NeedsUserAction,
                    "Shizuku: conceda a permissão ao LzKeyMap no diálogo do Shizuku (ou no app Shizuku > Apps autorizados).");
            }

            // sonda real: executa `input` através do processo privilegiado do Shizuku
            var p = NewProcess(cls, "sh", "-c", ProbeCommand);
            var output = ReadAll(p, 4000);
            return InterpretInputHelp(output) ?? Ok();
        }
        catch (System.Exception ex)
        {
            return new ExecutorStatus(ExecutorAvailability.Unsupported,
                $"Shizuku: falha ao falar com a lib (a reflexão pode ter quebrado nesta versão): {ex.Message}");
        }
    }

    static string ReadAll(Java.Lang.Process p, int timeoutMs)
    {
        var sb = new StringBuilder();
        // Read() bloqueia; roda numa tarefa e destrói o processo se estourar o prazo (senão a sonda poderia travar).
        var reader = Task.Run(() =>
        {
            var buf = new byte[1024];
            var input = p.InputStream!;
            try
            {
                int n;
                while ((n = input.Read(buf)) >= 0)
                {
                    lock (sb) sb.Append(Encoding.UTF8.GetString(buf, 0, n));
                    lock (sb) if (sb.ToString().Contains("LZ_DONE")) break;
                }
            }
            catch (System.Exception) { /* processo destruído */ }
        });
        reader.Wait(timeoutMs);
        try { p.Destroy(); } catch { }
        lock (sb) return sb.ToString();
    }

    protected override bool WriteLine(string command)
    {
        lock (gate)
        {
            try
            {
                if (shell == null || stdin == null)
                {
                    var cls = ShizukuClass() ?? throw new InvalidOperationException("lib ausente");
                    shell = NewProcess(cls, "sh");
                    stdin = shell.OutputStream!;
                    // descarta stdout/stderr para o pipe não encher
                    var o = shell.InputStream!; var e = shell.ErrorStream!;
                    Task.Run(() => Drain(o)); Task.Run(() => Drain(e));
                }
                stdin.Write(Encoding.UTF8.GetBytes(command + "\n"));
                stdin.Flush();
                return true;
            }
            catch (System.Exception)
            {
                try { shell?.Destroy(); } catch { }
                shell = null; stdin = null;
                return false;
            }
        }
    }

    static void Drain(Java.IO.InputStream s)
    {
        var buf = new byte[512];
        try { while (s.Read(buf) >= 0) { } } catch { }
    }

    public override void ReleaseAll()
    {
        base.ReleaseAll();
        lock (gate)
        {
            try { shell?.Destroy(); } catch { }
            shell = null; stdin = null;
        }
    }
}
