namespace LzKeyMap.Core.Execution;

public sealed class ExecutionManager : IExecutionManager
{
    const string PrefKey = "lz.exec_preferred";
    readonly object gate = new();
    IInputExecutor? active;

    public IReadOnlyList<IInputExecutor> All { get; }

    /// <summary>Ordem automática: Acessibilidade (multitoque real) → Root → Shizuku → ADB.</summary>
    public ExecutionManager(IEnumerable<IInputExecutor> executors) => All = executors.ToList();

    public IInputExecutor? Active { get { lock (gate) return active; } }

    public string? Preferred
    {
        get { var v = Preferences.Default.Get(PrefKey, ""); return string.IsNullOrEmpty(v) ? null : v; }
        set { if (value == null) Preferences.Default.Remove(PrefKey); else Preferences.Default.Set(PrefKey, value); }
    }

    IEnumerable<IInputExecutor> Ordered()
    {
        var pref = Preferred;
        var first = All.Where(e => e.Name == pref);
        return first.Concat(All.Where(e => e.Name != pref));
    }

    public IInputExecutor? Refresh()
    {
        IInputExecutor? found = null;
        foreach (var e in Ordered())
        {
            if (e.CheckAvailability().State == ExecutorAvailability.Available) { found = e; break; }
        }
        lock (gate) active = found;
        return found;
    }

    public void VerifyAll()
    {
        foreach (var e in All) e.CheckAvailability();
        Refresh();
    }

    /// <summary>Resumo honesto de por que nenhum método serve (para mostrar na UI).</summary>
    public string DescribeUnavailable() =>
        string.Join("\n", All.Select(e => $"• {e.Name}: {(e.LastStatus?.Explanation ?? "não verificado")}"));
}
