namespace LzKeyMap.Core.Execution;

/// <summary>
/// Base comum de Shizuku e ADB: manda os MESMOS comandos `input` do RootInputExecutor, porém por um shell
/// com privilégio de shell (uid 2000) em vez de `su`.
///
/// LIMITAÇÕES REAIS (aparecem em CheckAvailability, nunca escondidas):
///  - Cada `input` inicia um processo Java (app_process): ~100–300 ms. MaxSustainableHz é uma estimativa
///    conservadora (6 Hz), NÃO medida em aparelho.
///  - `input motionevent` injeta UM ponteiro só: apenas um "segurar" por vez (sem multitoque).
///  - `input motionevent` precisa existir no Android do aparelho; a sonda confere o texto de ajuda do `input`.
/// </summary>
public abstract class ShellInputExecutorBase : IInputExecutor
{
    public const int ShellMaxHz = 6;

    public abstract string Name { get; }
    public int MaxSustainableHz => ShellMaxHz;

    // ---- a implementar por cada método ----
    /// <summary>Conecta/valida de verdade e devolve o estado real. Deve preencher HoldSupported.</summary>
    protected abstract ExecutorStatus Probe();
    /// <summary>Escreve uma linha no shell persistente. false = falhou (conexão morreu).</summary>
    protected abstract bool WriteLine(string command);

    protected bool HoldSupported;

    readonly object gate = new();
    ExecutorStatus? cached;
    ExecutorStatus? last;
    public ExecutorStatus? LastStatus { get { lock (gate) return last; } }
    DateTime cachedAt = DateTime.MinValue;

    public ExecutorStatus CheckAvailability()
    {
        lock (gate)
        {
            if (cached != null && (DateTime.UtcNow - cachedAt).TotalSeconds < 3) return cached;
            try { cached = Probe(); }
            catch (Exception ex)
            {
                cached = new ExecutorStatus(ExecutorAvailability.Unsupported, $"{Name}: erro inesperado na verificação: {ex.Message}");
            }
            cachedAt = DateTime.UtcNow;
            last = cached;
            return cached;
        }
    }

    protected void InvalidateCache() { lock (gate) cached = null; }

    protected ExecutorStatus Ok(string extra = "") => new(ExecutorAvailability.Available,
        $"{Name} funcionando. Limites: ~{ShellMaxHz} Hz (cada comando `input` leva ~100–300 ms) e " +
        (HoldSupported ? "apenas UM toque segurado por vez (sem multitoque)." : "SEM suporte a segurar/arrastar neste Android (só toque simples).") + extra);

    /// <summary>Interpreta a saída do `input` (sem argumentos). Define HoldSupported.</summary>
    protected ExecutorStatus? InterpretInputHelp(string? output)
    {
        if (string.IsNullOrWhiteSpace(output) || !output.Contains("LZ_DONE"))
            return new ExecutorStatus(ExecutorAvailability.NeedsUserAction, $"{Name}: o shell não respondeu à sonda do comando `input`.");
        if (!output.Contains("tap"))
            return new ExecutorStatus(ExecutorAvailability.Unsupported, $"{Name}: o comando `input` não está disponível neste aparelho.");
        HoldSupported = output.Contains("motionevent");
        return null;
    }

    public const string ProbeCommand = "input; echo LZ_DONE";

    // ---- despacho ----
    static (int X, int Y) Px(float rx, float ry)
    {
        var (w, h) = ScreenInfo.Size();   // sempre relativo (0..1) -> pixels reais no momento do uso
        return ((int)Math.Round(Math.Clamp(rx, 0f, 1f) * (w - 1)), (int)Math.Round(Math.Clamp(ry, 0f, 1f) * (h - 1)));
    }

    int? heldId;
    long lastMoveTicks;
    (int X, int Y) lastPos;

    bool Send(string cmd)
    {
        if (WriteLine(cmd)) return true;
        InvalidateCache();   // a próxima checagem refaz a sonda e mostra o estado real
        return false;
    }

    public void Tap(float rx, float ry)
    {
        var (x, y) = Px(rx, ry);
        Send($"input tap {x} {y}");
    }

    public void BeginHold(int pointerId, float rx, float ry)
    {
        if (!HoldSupported || heldId != null) return;   // sem suporte / um ponteiro só
        var p = Px(rx, ry);
        if (Send($"input motionevent DOWN {p.X} {p.Y}")) { heldId = pointerId; lastPos = p; }
    }

    public void MoveHold(int pointerId, float rx, float ry)
    {
        if (heldId != pointerId) return;
        long now = Environment.TickCount64;
        if (now - lastMoveTicks < 1000 / ShellMaxHz) return;   // descarta excesso: o shell não acompanha
        lastMoveTicks = now;
        var p = Px(rx, ry);
        if (p == lastPos) return;
        lastPos = p;
        Send($"input motionevent MOVE {p.X} {p.Y}");
    }

    public void EndHold(int pointerId)
    {
        if (heldId != pointerId) return;
        heldId = null;
        Send($"input motionevent UP {lastPos.X} {lastPos.Y}");
    }

    /// <summary>Solta o toque segurado (se houver). Subclasses estendem para fechar o shell.</summary>
    public virtual void ReleaseAll()
    {
        if (heldId != null) { heldId = null; Send($"input motionevent UP {lastPos.X} {lastPos.Y}"); }
    }
}
