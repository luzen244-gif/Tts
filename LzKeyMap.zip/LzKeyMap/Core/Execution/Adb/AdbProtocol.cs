using System.Collections.Concurrent;
using System.Net.Sockets;
using System.Numerics;
using System.Security.Cryptography;
using System.Text;

namespace LzKeyMap.Core.Execution.Adb;

public sealed class AdbAuthPendingException : Exception
{
    public AdbAuthPendingException() : base("O aparelho está aguardando você aceitar o diálogo \"Permitir depuração USB?\".") { }
}

/// <summary>Chave RSA 2048 do app, no formato que o adbd entende (struct RSAPublicKey do Android).</summary>
internal sealed class AdbKey
{
    readonly RSA rsa;
    AdbKey(RSA rsa) => this.rsa = rsa;

    public static AdbKey LoadOrCreate(string dir)
    {
        var path = Path.Combine(dir, "adbkey.pk8");
        var rsa = RSA.Create(2048);
        if (File.Exists(path))
            rsa.ImportPkcs8PrivateKey(File.ReadAllBytes(path), out _);
        else
        {
            Directory.CreateDirectory(dir);
            File.WriteAllBytes(path, rsa.ExportPkcs8PrivateKey());
        }
        return new AdbKey(rsa);
    }

    /// <summary>AUTH_SIGNATURE: o adbd verifica RSA-SHA1 PKCS#1 tratando o token de 20 bytes como se fosse o hash.</summary>
    public byte[] Sign(byte[] token) => rsa.SignHash(token, HashAlgorithmName.SHA1, RSASignaturePadding.Pkcs1);

    public byte[] PublicKeyBlob()
    {
        var p = rsa.ExportParameters(false);
        var n = new BigInteger(p.Modulus!, isUnsigned: true, isBigEndian: true);
        const int words = 64;   // 2048 bits / 32

        uint n0 = (uint)(n & uint.MaxValue);
        uint inv = n0;
        unchecked { for (int i = 0; i < 5; i++) inv *= 2 - n0 * inv; }   // inverso de n0 mod 2^32 (n0 é ímpar)
        uint n0inv = unchecked(0u - inv);

        var rr = BigInteger.ModPow(2, 4096, n);   // (2^2048)^2 mod n

        var buf = new byte[4 + 4 + 256 + 256 + 4];
        BitConverter.TryWriteBytes(buf.AsSpan(0, 4), (uint)words);
        BitConverter.TryWriteBytes(buf.AsSpan(4, 4), n0inv);
        Pad(n.ToByteArray(isUnsigned: true, isBigEndian: false), 256).CopyTo(buf, 8);
        Pad(rr.ToByteArray(isUnsigned: true, isBigEndian: false), 256).CopyTo(buf, 8 + 256);
        var e = new BigInteger(p.Exponent!, isUnsigned: true, isBigEndian: true);
        BitConverter.TryWriteBytes(buf.AsSpan(8 + 512, 4), (uint)e);

        return Encoding.ASCII.GetBytes(Convert.ToBase64String(buf) + " lzkeymap@android\0");
    }

    static byte[] Pad(byte[] le, int len)
    {
        var r = new byte[len];
        Array.Copy(le, r, Math.Min(le.Length, len));
        return r;
    }
}

internal sealed class AdbStream
{
    public uint LocalId;
    public uint RemoteId;
    public readonly ManualResetEventSlim Ack = new(false);
    public readonly BlockingCollection<byte[]> Incoming = new();
    public volatile bool Closed;
    /// <summary>Shell persistente: a saída é descartada (senão acumula na memória).</summary>
    public bool Discard;
}

/// <summary>
/// Cliente mínimo do protocolo ADB "legado" (CNXN/AUTH/OPEN/WRTE) sobre TCP.
/// NÃO implementa o pareamento do Depuração Sem Fio do Android 11+ (SPAKE2 + TLS): só fala com um adbd
/// em TCP simples (ex.: após `adb tcpip 5555` feito uma vez por um PC). Isso é uma limitação real, mostrada na UI.
/// </summary>
internal sealed class AdbConnection : IDisposable
{
    const uint A_CNXN = 0x4e584e43, A_AUTH = 0x48545541, A_OPEN = 0x4e45504f,
               A_OKAY = 0x59414b4f, A_CLSE = 0x45534c43, A_WRTE = 0x45545257;
    const uint Version = 0x01000000;
    const uint HostMaxData = 256 * 1024;

    readonly TcpClient tcp = new() { NoDelay = true };
    NetworkStream net = null!;
    readonly object wlock = new();
    readonly ConcurrentDictionary<uint, AdbStream> streams = new();
    uint nextLocal = 1;
    int maxData = 4096;
    public volatile bool Alive;

    public static AdbConnection Connect(string host, int port, AdbKey key, int connectTimeoutMs, int authTimeoutMs)
    {
        var c = new AdbConnection();
        try
        {
            if (!c.tcp.ConnectAsync(host, port).Wait(connectTimeoutMs))
                throw new TimeoutException($"Sem resposta em {host}:{port}.");
            c.net = c.tcp.GetStream();
            c.Handshake(key, authTimeoutMs);
            c.Alive = true;
            new Thread(c.ReadLoop) { IsBackground = true, Name = "adb-reader" }.Start();
            return c;
        }
        catch { c.Dispose(); throw; }
    }

    static uint Sum(byte[] d) { uint s = 0; foreach (var b in d) s += b; return s; }

    void Send(uint cmd, uint a0, uint a1, byte[]? data = null)
    {
        data ??= Array.Empty<byte>();
        var h = new byte[24];
        BitConverter.TryWriteBytes(h.AsSpan(0), cmd);
        BitConverter.TryWriteBytes(h.AsSpan(4), a0);
        BitConverter.TryWriteBytes(h.AsSpan(8), a1);
        BitConverter.TryWriteBytes(h.AsSpan(12), (uint)data.Length);
        BitConverter.TryWriteBytes(h.AsSpan(16), Sum(data));
        BitConverter.TryWriteBytes(h.AsSpan(20), cmd ^ 0xFFFFFFFF);
        lock (wlock)
        {
            net.Write(h, 0, 24);
            if (data.Length > 0) net.Write(data, 0, data.Length);
            net.Flush();
        }
    }

    void ReadExact(byte[] buf, int len)
    {
        int off = 0;
        while (off < len)
        {
            int n = net.Read(buf, off, len - off);
            if (n <= 0) throw new IOException("Conexão ADB encerrada.");
            off += n;
        }
    }

    (uint Cmd, uint A0, uint A1, byte[] Data) Read()
    {
        var h = new byte[24];
        ReadExact(h, 24);
        uint cmd = BitConverter.ToUInt32(h, 0), a0 = BitConverter.ToUInt32(h, 4), a1 = BitConverter.ToUInt32(h, 8);
        uint len = BitConverter.ToUInt32(h, 12);
        if (len > 1024 * 1024) throw new IOException("Mensagem ADB inválida (tamanho).");
        var data = new byte[len];
        if (len > 0) ReadExact(data, (int)len);
        return (cmd, a0, a1, data);
    }

    void Handshake(AdbKey key, int authTimeoutMs)
    {
        net.ReadTimeout = authTimeoutMs;
        Send(A_CNXN, Version, HostMaxData, Encoding.ASCII.GetBytes("host::\0"));
        bool sentSig = false, sentKey = false;
        while (true)
        {
            (uint Cmd, uint A0, uint A1, byte[] Data) m;
            try { m = Read(); }
            catch (IOException) when (sentKey) { throw new AdbAuthPendingException(); }
            if (m.Cmd == A_CNXN)
            {
                maxData = (int)Math.Min(m.A1, 64 * 1024);
                if (maxData <= 0) maxData = 4096;
                net.ReadTimeout = Timeout.Infinite;
                return;
            }
            if (m.Cmd == A_AUTH && m.A0 == 1)
            {
                if (!sentSig) { Send(A_AUTH, 2, 0, key.Sign(m.Data)); sentSig = true; }
                else { Send(A_AUTH, 3, 0, key.PublicKeyBlob()); sentKey = true; }
                continue;
            }
            throw new IOException($"Resposta ADB inesperada (0x{m.Cmd:x}).");
        }
    }

    void ReadLoop()
    {
        try
        {
            while (true)
            {
                var m = Read();
                if (!streams.TryGetValue(m.A1, out var s)) continue;
                switch (m.Cmd)
                {
                    case A_OKAY: s.RemoteId = m.A0; s.Ack.Set(); break;
                    case A_WRTE:
                        if (!s.Discard) s.Incoming.Add(m.Data);
                        Send(A_OKAY, s.LocalId, s.RemoteId);
                        break;
                    case A_CLSE:
                        s.Closed = true; s.Ack.Set(); s.Incoming.CompleteAdding();
                        streams.TryRemove(s.LocalId, out _);
                        break;
                }
            }
        }
        catch (Exception)
        {
            Alive = false;
            foreach (var s in streams.Values) { s.Closed = true; s.Ack.Set(); s.Incoming.CompleteAdding(); }
        }
    }

    public AdbStream Open(string service, bool discard = false)
    {
        var s = new AdbStream { LocalId = Interlocked.Increment(ref nextLocal), Discard = discard };
        streams[s.LocalId] = s;
        Send(A_OPEN, s.LocalId, 0, Encoding.ASCII.GetBytes(service + "\0"));
        if (!s.Ack.Wait(5000) || s.Closed)
        { streams.TryRemove(s.LocalId, out _); throw new IOException($"O aparelho recusou abrir \"{service}\"."); }
        return s;
    }

    public void Write(AdbStream s, byte[] data)
    {
        if (!Alive || s.Closed) throw new IOException("Shell ADB fechado.");
        for (int off = 0; off < data.Length; off += maxData)
        {
            var chunk = data.AsSpan(off, Math.Min(maxData, data.Length - off)).ToArray();
            s.Ack.Reset();
            Send(A_WRTE, s.LocalId, s.RemoteId, chunk);
            if (!s.Ack.Wait(5000)) throw new TimeoutException("O aparelho não confirmou a escrita no shell.");
            if (s.Closed) throw new IOException("Shell ADB fechado.");
        }
    }

    /// <summary>Executa um comando e devolve a saída completa (ou o que veio até o timeout).</summary>
    public string Exec(string command, int timeoutMs)
    {
        var s = Open("shell:" + command);
        var sb = new StringBuilder();
        var end = DateTime.UtcNow.AddMilliseconds(timeoutMs);
        while (!s.Incoming.IsCompleted && DateTime.UtcNow < end)
            if (s.Incoming.TryTake(out var chunk, 100)) sb.Append(Encoding.UTF8.GetString(chunk));
        return sb.ToString();
    }

    public void Dispose()
    {
        Alive = false;
        try { tcp.Close(); } catch { }
    }
}
