using Android.AccessibilityServices;
using Android.Graphics;
using LzKeyMap.Services;
using Path = Android.Graphics.Path;

namespace LzKeyMap.Core.Execution;

/// <summary>
/// Toques via AccessibilityService.dispatchGesture. Multitoque real: a cada passo é despachado UM gesto contendo os
/// traços de TODOS os ponteiros ativos (cada traço "continua" o anterior, willContinue = true). Um novo gesto só sai
/// quando o anterior terminou (callback), porque despachar por cima cancelaria o gesto em andamento.
/// Limite real: ~1 gesto a cada SegmentMs => ~60 Hz. Requer API 26+ (continued gestures).
/// </summary>
public sealed class AccessibilityInputExecutor : IInputExecutor
{
    const int SegmentMs = 16;
    const int TapMs = 40;

    public string Name => "Acessibilidade";
    public int MaxSustainableHz => 1000 / SegmentMs;   // 62

    sealed class Ptr
    {
        public GestureDescription.StrokeDescription? Stroke;
        public float X, Y, TX, TY;
        public bool Ending;
    }

    sealed class Cb : AccessibilityService.GestureResultCallback
    {
        readonly AccessibilityInputExecutor owner;
        public Cb(AccessibilityInputExecutor o) => owner = o;
        public override void OnCompleted(GestureDescription? gestureDescription) => owner.Completed(false);
        public override void OnCancelled(GestureDescription? gestureDescription) => owner.Completed(true);
    }

    readonly object gate = new();
    readonly Dictionary<int, Ptr> ptrs = new();
    readonly List<(float X, float Y)> taps = new();
    readonly Cb callback;
    bool inFlight;
    ExecutorStatus? last;

    public AccessibilityInputExecutor() => callback = new Cb(this);

    public ExecutorStatus? LastStatus { get { lock (gate) return last; } }

    public ExecutorStatus CheckAvailability()
    {
        ExecutorStatus st;
        if (LzKeyMapAccessibilityService.Instance == null)
            st = new(ExecutorAvailability.NeedsUserAction,
                "Acessibilidade: ative o serviço \"LzKeyMap\" em Configurações > Acessibilidade (ele captura o teclado e injeta os toques).");
        else
            st = new(ExecutorAvailability.Available,
                $"Acessibilidade funcionando: teclado em todo o sistema e multitoque real. Limite ~{MaxSustainableHz} Hz. " +
                "Não captura o mouse (só teclado); para mouse use Root.");
        lock (gate) last = st;
        return st;
    }

    static (float X, float Y) Px(float rx, float ry)
    {
        var (w, h) = ScreenInfo.Size();
        return (Math.Clamp(rx, 0f, 1f) * (w - 1), Math.Clamp(ry, 0f, 1f) * (h - 1));
    }

    public void Tap(float rx, float ry)
    {
        var p = Px(rx, ry);
        lock (gate) { taps.Add(p); Flush(); }
    }

    public void BeginHold(int id, float rx, float ry)
    {
        var p = Px(rx, ry);
        lock (gate)
        {
            if (ptrs.ContainsKey(id)) return;
            ptrs[id] = new Ptr { X = p.X, Y = p.Y, TX = p.X, TY = p.Y };
            Flush();
        }
    }

    public void MoveHold(int id, float rx, float ry)
    {
        var p = Px(rx, ry);
        lock (gate)
        {
            if (!ptrs.TryGetValue(id, out var ptr) || ptr.Ending) return;
            ptr.TX = p.X; ptr.TY = p.Y;
            Flush();   // se há gesto em voo, o alvo novo entra no próximo
        }
    }

    public void EndHold(int id)
    {
        lock (gate)
        {
            if (!ptrs.TryGetValue(id, out var ptr)) return;
            ptr.Ending = true;
            Flush();
        }
    }

    public void ReleaseAll()
    {
        lock (gate)
        {
            foreach (var p in ptrs.Values) p.Ending = true;
            taps.Clear();
            Flush();
        }
    }

    // chamado com 'gate' travado
    void Flush()
    {
        if (inFlight) return;
        var svc = LzKeyMapAccessibilityService.Instance;
        if (svc == null) { ptrs.Clear(); taps.Clear(); return; }

        var b = new GestureDescription.Builder();
        int count = 0, max = GestureDescription.MaxStrokeCount;
        var finished = new List<int>();

        foreach (var (id, p) in ptrs)
        {
            if (count >= max) break;
            var path = new Path();
            path.MoveTo(p.X, p.Y);
            path.LineTo(p.TX, p.TY);
            bool willContinue = !p.Ending;
            var stroke = p.Stroke == null
                ? new GestureDescription.StrokeDescription(path, 0, SegmentMs, willContinue)
                : p.Stroke.ContinueStroke(path, 0, SegmentMs, willContinue);
            p.Stroke = stroke;
            p.X = p.TX; p.Y = p.TY;
            b.AddStroke(stroke);
            count++;
            if (p.Ending) finished.Add(id);
        }
        foreach (var id in finished) ptrs.Remove(id);

        foreach (var t in taps)
        {
            if (count >= max) break;
            var path = new Path();
            path.MoveTo(t.X, t.Y);
            b.AddStroke(new GestureDescription.StrokeDescription(path, 0, TapMs));
            count++;
        }
        taps.Clear();

        if (count == 0) return;
        inFlight = true;
        bool ok;
        try { ok = svc.DispatchGesture(b.Build(), callback, null); }
        catch (Exception) { ok = false; }
        if (!ok) { inFlight = false; ptrs.Clear(); }   // estado perdido: o motor recomeça no próximo toque
    }

    void Completed(bool cancelled)
    {
        lock (gate)
        {
            inFlight = false;
            if (cancelled) { ptrs.Clear(); taps.Clear(); return; }   // o sistema cancelou: os traços "continuados" não valem mais
            if (ptrs.Count > 0 || taps.Count > 0) Flush();           // mantém o toque segurado vivo e entrega o que chegou
        }
    }
}
