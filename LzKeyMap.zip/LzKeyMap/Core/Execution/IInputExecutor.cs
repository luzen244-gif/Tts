namespace LzKeyMap.Core.Execution;

public enum ExecutorAvailability { Available, NeedsUserAction, Unsupported }

public sealed record ExecutorStatus(ExecutorAvailability State, string Explanation);

/// <summary>
/// Injeta toques. Coordenadas SEMPRE relativas (0..1). pointerId: 0 analógico, 1 vista, 2.. demais.
/// Implementações não podem bloquear por muito tempo: o motor as chama de uma thread dedicada.
/// </summary>
public interface IInputExecutor
{
    string Name { get; }
    /// <summary>Verifica de verdade (pode demorar/pedir permissão). Nunca chame na thread de UI.</summary>
    ExecutorStatus CheckAvailability();
    /// <summary>Último resultado de CheckAvailability, sem custo e sem efeito colateral (null = nunca verificado).</summary>
    ExecutorStatus? LastStatus { get; }
    int MaxSustainableHz { get; }
    void Tap(float rx, float ry);
    void BeginHold(int pointerId, float rx, float ry);
    void MoveHold(int pointerId, float rx, float ry);
    void EndHold(int pointerId);
    /// <summary>Solta tudo e libera recursos (shell, conexões).</summary>
    void ReleaseAll();
}

public interface IExecutionManager
{
    IReadOnlyList<IInputExecutor> All { get; }
    IInputExecutor? Active { get; }
    /// <summary>Nome do método preferido pelo usuário (null = automático).</summary>
    string? Preferred { get; set; }
    /// <summary>Verifica na ordem de preferência até achar um disponível e o define como Active. Thread de fundo.</summary>
    IInputExecutor? Refresh();
    /// <summary>Verifica TODOS (para a tela de permissões). Thread de fundo.</summary>
    void VerifyAll();
}
