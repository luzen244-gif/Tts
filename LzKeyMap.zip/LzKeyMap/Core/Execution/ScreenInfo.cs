using Android.Content;
using Android.Runtime;
using Android.Util;
using Android.Views;

namespace LzKeyMap.Core.Execution;

public static class ScreenInfo
{
    /// <summary>Resolução real da tela em pixels (inclui barras do sistema). É a única fonte de "pixels" do app.</summary>
    public static (int W, int H) Size()
    {
        var wm = Android.App.Application.Context.GetSystemService(Context.WindowService)!.JavaCast<IWindowManager>();
        var dm = new DisplayMetrics();
#pragma warning disable CA1422
        wm.DefaultDisplay!.GetRealMetrics(dm);
#pragma warning restore CA1422
        return (dm.WidthPixels, dm.HeightPixels);
    }
}
