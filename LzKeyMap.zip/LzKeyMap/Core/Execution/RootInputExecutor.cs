using System.ComponentModel;
using System.Diagnostics;
using System.Text;

namespace LzKeyMap.Core.Execution;

/// <summary>
/// Root: `su` + binário `input` do Android. Mesmos limites do shell (ver ShellInputExecutorBase): ~6 Hz e UM toque segurado.
/// A captura do MOUSE é outra coisa (RawInputService/evdev_reader) e também usa root.
/// A verificação roda `su` de verdade (pode abrir o pedido do Magisk/KernelSU): nunca chame na thread de UI.
/// </summary>
public sealed class RootInputExecutor : ShellInputExecutorBase
{
    public override string Name => "Root";

    Process? su;
    readonly object procGate = new();

    protected override ExecutorStatus Probe()
    {
        try
        {
            var psi = new ProcessStartInfo("su")
            {
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false
            };
            using var p = Process.Start(psi)!;
            p.StandardInput.WriteLine(ProbeCommand);
            p.StandardInput.WriteLine("exit");
            p.StandardInput.Flush();

            var sb = new StringBuilder();
            var reader = Task.Run(() => { try { sb.Append(p.StandardOutput.ReadToEnd()); } catch { } });
            if (!p.WaitForExit(8000))
            {
                try { p.Kill(); } catch { }
                return new ExecutorStatus(ExecutorAvailability.NeedsUserAction,
                    "Root: o su não respondeu em 8 s. Se apareceu um pedido do Magisk/KernelSU, conceda e verifique de novo.");
            }
            reader.Wait(1000);
            var output = sb.ToString();
            if (p.ExitCode != 0 && !output.Contains("LZ_DONE"))
                return new ExecutorStatus(ExecutorAvailability.NeedsUserAction,
                    "Root: o su negou o acesso. Conceda root ao LzKeyMap no Magisk/KernelSU e verifique de novo.");
            return InterpretInputHelp(output) ?? Ok();
        }
        catch (Win32Exception)
        {
            return new ExecutorStatus(ExecutorAvailability.Unsupported, "Root: binário `su` não encontrado — o aparelho não tem root.");
        }
    }

    protected override bool WriteLine(string command)
    {
        lock (procGate)
        {
            try
            {
                if (su == null || su.HasExited)
                {
                    su = Process.Start(new ProcessStartInfo("su")
                    {
                        RedirectStandardInput = true,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        UseShellExecute = false
                    })!;
                    var o = su.StandardOutput; var e = su.StandardError;
                    Task.Run(() => Drain(o)); Task.Run(() => Drain(e));   // senão o pipe enche e o shell trava
                }
                su.StandardInput.WriteLine(command);
                su.StandardInput.Flush();
                return true;
            }
            catch (Exception)
            {
                try { su?.Kill(); } catch { }
                su = null;
                return false;
            }
        }
    }

    static void Drain(StreamReader r)
    {
        try { while (r.ReadLine() != null) { } } catch { }
    }

    public override void ReleaseAll()
    {
        base.ReleaseAll();
        lock (procGate)
        {
            try { su?.StandardInput.WriteLine("exit"); su?.StandardInput.Flush(); } catch { }
            try { su?.Kill(); } catch { }
            su = null;
        }
    }
}
