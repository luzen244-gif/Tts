using Android.Content;
using Android.Provider;
using LzKeyMap.Core.Execution;
using LzKeyMap.Services;

namespace LzKeyMap.Core.Permissions;

public sealed record PermissionInfo(string Id, string Name, string Description, ExecutorAvailability State, string Detail);

/// <summary>
/// Estado REAL das permissões/métodos. GetAll() é barato e seguro na thread de UI: overlay e acessibilidade são
/// consultados na hora; Root/Shizuku/ADB mostram o ÚLTIMO resultado verificado (ou "não verificado"), porque verificá-los
/// executa `su`, fala com o Shizuku e abre sockets — isso só acontece em IExecutionManager.VerifyAll()/Refresh() (fundo).
/// </summary>
public sealed class PermissionManager
{
    readonly IExecutionManager execution;
    public PermissionManager(IExecutionManager execution) => this.execution = execution;

    public IReadOnlyList<PermissionInfo> GetAll()
    {
        var ctx = Android.App.Application.Context;
        var list = new List<PermissionInfo>();

        bool overlay = Settings.CanDrawOverlays(ctx);
        list.Add(new("overlay", "Sobreposição", "Desenhar a barra e o editor de HUD por cima do jogo.",
            overlay ? ExecutorAvailability.Available : ExecutorAvailability.NeedsUserAction,
            overlay ? "Permitido." : "Conceda \"Sobrepor a outros apps\" ao LzKeyMap."));

        list.Add(Accessibility(ctx));
        list.Add(Peek("root", "ROOT", "Injeta toques com `su` e captura o mouse (evdev).", "Root"));
        list.Add(Peek("shizuku", "Shizuku", "Injeta toques pelo processo privilegiado do Shizuku.", "Shizuku"));
        list.Add(Peek("adb", "ADB", "Injeta toques por um adbd local (TCP).", "ADB"));
        return list;
    }

    static PermissionInfo Accessibility(Context ctx)
    {
        string enabledStr = Settings.Secure.GetString(ctx.ContentResolver, Settings.Secure.EnabledAccessibilityServices) ?? "";
        bool enabled = enabledStr.Split(':', StringSplitOptions.RemoveEmptyEntries).Any(s =>
        {
            var cn = ComponentName.UnflattenFromString(s);
            return cn != null && cn.PackageName == ctx.PackageName && cn.ClassName == LzKeyMapAccessibilityService.ServiceName;
        });
        bool connected = LzKeyMapAccessibilityService.Instance != null;

        if (enabled && connected)
            return new("accessibility", "Acessibilidade", "Captura o teclado em todo o sistema e despacha toques.",
                ExecutorAvailability.Available, "Serviço ativo e conectado.");
        if (enabled)
            return new("accessibility", "Acessibilidade", "Captura o teclado em todo o sistema e despacha toques.",
                ExecutorAvailability.NeedsUserAction, "Ligado nas configurações, mas ainda não conectado. Desligue e ligue de novo o serviço LzKeyMap.");
        return new("accessibility", "Acessibilidade", "Captura o teclado em todo o sistema e despacha toques.",
            ExecutorAvailability.NeedsUserAction, "Ative o serviço \"LzKeyMap\" em Configurações > Acessibilidade.");
    }

    PermissionInfo Peek(string id, string name, string desc, string executorName)
    {
        var st = execution.All.FirstOrDefault(e => e.Name == executorName)?.LastStatus;
        return st == null
            ? new(id, name, desc, ExecutorAvailability.NeedsUserAction, "Ainda não verificado. Use VERIFICAR (a verificação é manual).")
            : new(id, name, desc, st.State, st.Explanation);
    }
}
