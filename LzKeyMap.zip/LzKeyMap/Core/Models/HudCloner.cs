using System.Text.Json;

namespace LzKeyMap.Core.Models;

/// <summary>Clonagem de HUD/componente (duplicar). Não grava nada: quem grava é sempre o ProfileStore.</summary>
public static class HudCloner
{
    public static HudComponent CloneComponent(HudComponent src, float offset = 0.03f)
    {
        var json = JsonSerializer.Serialize(src);
        var c = JsonSerializer.Deserialize<HudComponent>(json)!;
        c.Id = Guid.NewGuid().ToString("N");
        c.RelativeX = Math.Clamp(src.RelativeX + offset, 0f, 1f);
        c.RelativeY = Math.Clamp(src.RelativeY + offset, 0f, 1f);
        c.Locked = false;
        return c;
    }

    public static HudProfile CloneProfile(HudProfile src, string newName)
    {
        var json = JsonSerializer.Serialize(src);
        var p = JsonSerializer.Deserialize<HudProfile>(json)!;
        p.Id = Guid.NewGuid().ToString("N");
        p.Name = newName;
        foreach (var c in p.Components) c.Id = Guid.NewGuid().ToString("N");
        return p;
    }
}
