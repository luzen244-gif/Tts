using System.Text.Json.Serialization;

namespace LzKeyMap.Core.Models;

public enum ComponentKind { Analog, Shoot, Tap, Press, View, Macro }

/// <summary>O valor numérico do enum É o Hz.</summary>
public enum OutputFrequencyHz { Hz125 = 125, Hz250 = 250, Hz500 = 500, Hz1000 = 1000, Hz2000 = 2000 }

/// <summary>Códigos de entrada unificados: teclas = KeyCode do Android; botões do mouse = MouseBase + código evdev (BTN_*).</summary>
public static class InputCodes
{
    public const int MouseBase = 0x10000;
    public const int BtnLeft = 0x110, BtnRight = 0x111, BtnMiddle = 0x112, BtnSide = 0x113, BtnExtra = 0x114;

    public static bool IsMouse(int code) => code >= MouseBase;

    public static string MouseLabel(int evdevButton) => evdevButton switch
    {
        BtnLeft => "Mouse Esq.",
        BtnRight => "Mouse Dir.",
        BtnMiddle => "Mouse Meio",
        BtnSide => "Mouse Lat.",
        BtnExtra => "Mouse Extra",
        _ => $"Mouse {evdevButton:x}"
    };
}

public class HudComponent
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public ComponentKind Kind { get; set; }

    /// <summary>Centro do componente, relativo à tela (0..1). NUNCA pixels.</summary>
    public float RelativeX { get; set; } = 0.5f;
    public float RelativeY { get; set; } = 0.5f;
    /// <summary>Diâmetro = RelativeSize × lado menor da tela.</summary>
    public float RelativeSize { get; set; } = 0.12f;
    public int OpacityPercent { get; set; } = 70;
    public bool Locked { get; set; }

    /// <summary>
    /// Shoot/Tap/Press/Macro: tecla ou botão do mouse que aciona o componente.
    /// View: tecla que alterna "seta/cursor livre" (Vista pausada) ↔ "mira" (Vista ativa).
    /// </summary>
    public int KeyCode { get; set; }
    public string? KeyLabel { get; set; }

    // Analógico: 4 teclas (0 = não atribuída)
    public int KeyUp { get; set; }
    public int KeyDown { get; set; }
    public int KeyLeft { get; set; }
    public int KeyRight { get; set; }

    /// <summary>Macro: enquanto a tecla estiver pressionada, toca na posição do componente a cada N ms (auto-toque).</summary>
    public int MacroIntervalMs { get; set; } = 60;
}

public class ViewSettings
{
    public double SensitivityX { get; set; } = 1.0;
    public double SensitivityY { get; set; } = 1.0;
    public OutputFrequencyHz Frequency { get; set; } = OutputFrequencyHz.Hz125;
    public bool InvertX { get; set; }
    public bool InvertY { get; set; }
    public double DeadZone { get; set; }
    public double Smoothing { get; set; }
    public double MouseSpeed { get; set; } = 1.0;
    public bool LockHudEditing { get; set; }

    public static ViewSettings Defaults() => new();
}

public class HudProfile
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "HUD";
    public string GamePackage { get; set; } = "";
    public List<HudComponent> Components { get; set; } = new();
    public ViewSettings View { get; set; } = ViewSettings.Defaults();
}
