namespace LzKeyMap.Core.Models;

/// <summary>
/// ÚNICO ponto que conhece os nomes do enum ComponentKind da Fase 1.
/// Se os nomes do seu enum forem diferentes, ajuste apenas aqui.
/// </summary>
public static class ComponentKindInfo
{
    public static readonly ComponentKind[] All =
    {
        ComponentKind.Analog, ComponentKind.Shoot, ComponentKind.Tap,
        ComponentKind.Press, ComponentKind.View, ComponentKind.Macro
    };

    public static string Label(this ComponentKind k) => k switch
    {
        ComponentKind.Analog => "Analógico",
        ComponentKind.Shoot => "Tiro",
        ComponentKind.Tap => "Toque",
        ComponentKind.Press => "Pressionar",
        ComponentKind.View => "Vista",
        ComponentKind.Macro => "Macro",
        _ => k.ToString()
    };

    /// <summary>Cor ARGB (0xAARRGGBB) usada no desenho do editor.</summary>
    public static uint ColorArgb(this ComponentKind k) => k switch
    {
        ComponentKind.Analog => 0xFF3B82F6,
        ComponentKind.Shoot => 0xFFEF4444,
        ComponentKind.Tap => 0xFF22C55E,
        ComponentKind.Press => 0xFFF59E0B,
        ComponentKind.View => 0xFFA855F7,
        ComponentKind.Macro => 0xFF14B8A6,
        _ => 0xFF9CA3AF
    };

    /// <summary>Tem exatamente uma tecla associada editável pelo seletor simples?</summary>
    public static bool HasSingleKey(this ComponentKind k) =>
        k is ComponentKind.Shoot or ComponentKind.Tap or ComponentKind.Press or ComponentKind.Macro or ComponentKind.View;

    public static string WhyNoSingleKey(this ComponentKind k) => k switch
    {
        ComponentKind.Analog => "Analógico usa 4 teclas (cima/baixo/esq/dir). Edição por direção ainda não implementada.",
        _ => ""
    };
}
