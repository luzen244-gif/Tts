using System.Text.Json;

namespace LzKeyMap.Core.Storage;

/// <summary>
/// Preferências leves (NÃO são HUDs — HUDs continuam só no ProfileStore):
///  - lista de apps/jogos escolhidos na Home;
///  - qual HUD está "em uso" para cada jogo.
/// </summary>
public sealed class ChosenAppsStore
{
    const string KeyApps = "lz.chosen_apps";
    const string KeyActivePrefix = "lz.active_hud.";

    public IReadOnlyList<string> GetPackages()
    {
        try
        {
            var json = Preferences.Default.Get(KeyApps, "[]");
            return JsonSerializer.Deserialize<List<string>>(json) ?? new List<string>();
        }
        catch (JsonException) { return new List<string>(); }
    }

    void Write(IEnumerable<string> list) =>
        Preferences.Default.Set(KeyApps, JsonSerializer.Serialize(list.Distinct().ToList()));

    public void Add(string package)
    {
        var l = GetPackages().ToList();
        if (!l.Contains(package)) { l.Add(package); Write(l); }
    }

    public void Remove(string package)
    {
        Write(GetPackages().Where(p => p != package));
        Preferences.Default.Remove(KeyActivePrefix + package);
    }

    public string? GetActiveHudId(string package)
    {
        var v = Preferences.Default.Get(KeyActivePrefix + package, "");
        return string.IsNullOrEmpty(v) ? null : v;
    }

    public void SetActiveHudId(string package, string hudId) =>
        Preferences.Default.Set(KeyActivePrefix + package, hudId);
}
