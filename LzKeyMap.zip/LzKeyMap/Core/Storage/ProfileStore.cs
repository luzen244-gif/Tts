using System.Text.Json;
using System.Text.Json.Serialization;
using LzKeyMap.Core.Models;

namespace LzKeyMap.Core.Storage;

/// <summary>
/// ÚNICO caminho de gravação de HUDs. Arquivos:
///   {raiz}/huds/{pacote}/{id}.json        — HUD ativo
///   {raiz}/backups/{pacote}/{id}_{data}.json — gerado por Delete (e nunca apagado automaticamente)
/// Formato: { "formatVersion": 1, "profile": { ... } }. Import valida e NUNCA sobrescreve um HUD existente
/// (se o Id já existe, o importado recebe um Id novo).
/// </summary>
public sealed class ProfileStore
{
    public const int FormatVersion = 1;

    static readonly JsonSerializerOptions Json = new()
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() }
    };

    sealed class Envelope
    {
        public int FormatVersion { get; set; }
        public HudProfile? Profile { get; set; }
    }

    readonly string root;
    readonly object gate = new();

    public ProfileStore() : this(FileSystem.AppDataDirectory) { }
    public ProfileStore(string rootDir) => root = rootDir;

    static string Safe(string s)
    {
        var bad = Path.GetInvalidFileNameChars();
        var r = new string(s.Select(c => bad.Contains(c) || c == '/' ? '_' : c).ToArray());
        return string.IsNullOrWhiteSpace(r) ? "_" : r;
    }

    string HudDir(string pkg) => Path.Combine(root, "huds", Safe(pkg));
    string BackupDir(string pkg) => Path.Combine(root, "backups", Safe(pkg));
    string HudPath(HudProfile p) => Path.Combine(HudDir(p.GamePackage), Safe(p.Id) + ".json");

    static void WriteAtomic(string path, string content)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var tmp = path + ".tmp";
        File.WriteAllText(tmp, content);
        File.Move(tmp, path, overwrite: true);
    }

    static string Serialize(HudProfile p) =>
        JsonSerializer.Serialize(new Envelope { FormatVersion = FormatVersion, Profile = p }, Json);

    static HudProfile Parse(string text)
    {
        Envelope? env;
        try { env = JsonSerializer.Deserialize<Envelope>(text, Json); }
        catch (JsonException) { throw new InvalidDataException("Arquivo inválido: não é um HUD do LzKeyMap."); }
        if (env?.Profile == null) throw new InvalidDataException("Arquivo inválido: não é um HUD do LzKeyMap.");
        if (env.FormatVersion > FormatVersion)
            throw new InvalidDataException($"Versão incompatível ({env.FormatVersion}). Este app lê até a versão {FormatVersion}; atualize o app.");
        if (env.FormatVersion < 1) throw new InvalidDataException("Arquivo inválido: versão ausente.");
        var p = env.Profile;
        if (string.IsNullOrWhiteSpace(p.Name)) p.Name = "HUD importado";
        p.Components ??= new List<HudComponent>();
        p.View ??= ViewSettings.Defaults();
        if (string.IsNullOrWhiteSpace(p.Id)) p.Id = Guid.NewGuid().ToString("N");
        foreach (var c in p.Components)
        {
            c.Id = string.IsNullOrWhiteSpace(c.Id) ? Guid.NewGuid().ToString("N") : c.Id;
            c.RelativeX = Math.Clamp(c.RelativeX, 0f, 1f);
            c.RelativeY = Math.Clamp(c.RelativeY, 0f, 1f);
            c.RelativeSize = Math.Clamp(c.RelativeSize, 0.02f, 0.8f);
            c.OpacityPercent = Math.Clamp(c.OpacityPercent, 5, 100);
            c.MacroIntervalMs = Math.Clamp(c.MacroIntervalMs, 20, 5000);
        }
        return p;
    }

    public void Save(HudProfile p)
    {
        if (string.IsNullOrWhiteSpace(p.GamePackage)) throw new InvalidOperationException("HUD sem jogo associado.");
        lock (gate)
        {
            WriteAtomic(HudPath(p), Serialize(p));
        }
    }

    public IReadOnlyList<HudProfile> GetHudsForGame(string gamePackage)
    {
        lock (gate)
        {
            var dir = HudDir(gamePackage);
            if (!Directory.Exists(dir)) return new List<HudProfile>();
            var list = new List<HudProfile>();
            foreach (var f in Directory.EnumerateFiles(dir, "*.json"))
            {
                try { list.Add(Parse(File.ReadAllText(f))); }
                catch (Exception) { /* arquivo corrompido: ignora, não derruba a lista */ }
            }
            return list.OrderBy(h => h.Name, StringComparer.CurrentCultureIgnoreCase).ToList();
        }
    }

    public void Delete(HudProfile p)
    {
        lock (gate)
        {
            var path = HudPath(p);
            if (!File.Exists(path)) return;
            var backup = Path.Combine(BackupDir(p.GamePackage), $"{Safe(p.Id)}_{DateTime.Now:yyyyMMdd_HHmmss_fff}.json");
            WriteAtomic(backup, Serialize(p));   // só apaga depois que o backup existe
            File.Delete(path);
        }
    }

    public IReadOnlyList<string> GetBackups(string gamePackage)
    {
        lock (gate)
        {
            var dir = BackupDir(gamePackage);
            if (!Directory.Exists(dir)) return new List<string>();
            return Directory.EnumerateFiles(dir, "*.json").OrderByDescending(f => f).ToList();
        }
    }

    /// <summary>Lê, valida e salva. forceGamePackage move o HUD para esse jogo antes de gravar (sem deixar cópia no jogo antigo).</summary>
    public HudProfile Import(string path, string? forceGamePackage = null)
    {
        HudProfile p;
        try { p = Parse(File.ReadAllText(path)); }
        catch (IOException ex) { throw new InvalidDataException("Não foi possível ler o arquivo: " + ex.Message); }
        if (!string.IsNullOrEmpty(forceGamePackage)) p.GamePackage = forceGamePackage;
        if (string.IsNullOrWhiteSpace(p.GamePackage)) throw new InvalidDataException("O HUD não diz a qual jogo pertence.");
        lock (gate)
        {
            if (File.Exists(HudPath(p)))   // nunca sobrescreve
            {
                p.Id = Guid.NewGuid().ToString("N");
                foreach (var c in p.Components) c.Id = Guid.NewGuid().ToString("N");
                p.Name += " (importado)";
            }
            Save(p);
        }
        return p;
    }

    public void Export(HudProfile p, string path)
    {
        lock (gate) WriteAtomic(path, Serialize(p));
    }
}
