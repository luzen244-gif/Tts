using System.Collections.Concurrent;
using System.Diagnostics;
using LzKeyMap.Core.Execution;
using LzKeyMap.Core.Models;

namespace LzKeyMap.Core.Engine;

/// <summary>
/// Motor de mapeamento. Não conhece Android: recebe eventos (teclas/botões/delta do mouse) e comanda um IInputExecutor.
///
/// Os 6 componentes:
///  - Analógico: 4 teclas; segura um dedo (ponteiro 0) no centro e o desloca na direção das teclas (8 direções).
///  - Tiro:      enquanto a tecla/botão estiver pressionado, segura o dedo no componente; o mouse passa a "arrastar"
///               esse dedo (mira enquanto atira), limitado ao raio de arraste (não dá para recentralizar sem soltar o tiro).
///  - Toque:     um toque no pressionar.
///  - Pressionar: segura enquanto pressionado (sem mira).
///  - Vista:     o delta do mouse arrasta um dedo (ponteiro 1) a partir do componente; ao chegar na borda do raio,
///               solta e recomeça no centro; parado por ~120 ms, solta. A tecla do componente alterna Vista ativa/pausada.
///  - Macro:     auto-toque na posição do componente enquanto a tecla estiver pressionada (a cada MacroIntervalMs).
///
/// Garantias: repetição de tecla (auto-repeat) não duplica toque; soltar sempre libera; Stop/Reload soltam tudo.
/// Todas as chamadas ao executor saem de UMA thread (fila), então um executor lento nunca trava quem chamou OnKey.
/// </summary>
public sealed class MappingEngine : IDisposable
{
    const int AnalogPtr = 0, ViewPtr = 1, FirstFreePtr = 2, LastPtr = 9;
    const double ViewIdleMs = 120;
    const float DragRadiusOfShortSide = 0.18f;

    sealed class Drag
    {
        public int Ptr;
        public float Cx, Cy, OffX, OffY;
        public bool Active;
        public long LastMoveMs;
    }

    readonly IInputExecutor ex;
    readonly Func<(int W, int H)> screen;
    readonly object gate = new();
    readonly BlockingCollection<Action> queue = new();
    readonly Stopwatch clock = Stopwatch.StartNew();

    Thread? worker, ticker;
    volatile bool running;
    volatile int periodMs = 16;

    HudProfile? profile;
    ViewMotionProcessor? motion;
    HudComponent? analog, viewComp;
    readonly Dictionary<int, List<HudComponent>> byKey = new();
    readonly HashSet<int> down = new();
    readonly Dictionary<string, Drag> pressed = new();          // Shoot/Press ativos: id do componente -> ponteiro
    readonly Dictionary<string, bool> pressedAims = new();      // o ponteiro é de Tiro (mira)?
    readonly Dictionary<string, CancellationTokenSource> macros = new();
    readonly bool[] ptrUsed = new bool[LastPtr + 1];
    Drag viewDrag = new() { Ptr = ViewPtr };
    bool analogHeld;
    bool viewEnabled = true;
    float accX, accY;

    public MappingEngine(IInputExecutor executor, Func<(int W, int H)> screenSize)
    {
        ex = executor;
        screen = screenSize;
    }

    public bool Running => running;
    public bool ViewEnabled { get { lock (gate) return viewEnabled; } }
    public IInputExecutor Executor => ex;
    /// <summary>Hz realmente aplicado ao ritmo da Vista (limitado pelo método de execução).</summary>
    public int EffectiveHz { get; private set; }

    // ---------------- ciclo de vida ----------------
    public void Start(HudProfile p)
    {
        lock (gate)
        {
            if (running) return;
            running = true;
            Load(p);
        }
        worker = new Thread(WorkerLoop) { IsBackground = true, Name = "lz-exec" };
        ticker = new Thread(TickLoop) { IsBackground = true, Name = "lz-tick" };
        worker.Start();
        ticker.Start();
    }

    /// <summary>Recarrega o HUD (ex.: depois de salvar no editor) soltando tudo antes.</summary>
    public void Reload(HudProfile p)
    {
        lock (gate) { if (running) Load(p); }
    }

    void Load(HudProfile p)
    {
        ReleaseAllLocked();
        profile = p;
        p.View ??= ViewSettings.Defaults();
        byKey.Clear();
        analog = p.Components.FirstOrDefault(c => c.Kind == ComponentKind.Analog);
        viewComp = p.Components.FirstOrDefault(c => c.Kind == ComponentKind.View);
        foreach (var c in p.Components)
        {
            if (c.Kind is ComponentKind.Shoot or ComponentKind.Tap or ComponentKind.Press or ComponentKind.Macro && c.KeyCode != 0)
            {
                if (!byKey.TryGetValue(c.KeyCode, out var l)) byKey[c.KeyCode] = l = new List<HudComponent>();
                l.Add(c);
            }
        }
        viewDrag = new Drag { Ptr = ViewPtr, Cx = viewComp?.RelativeX ?? 0.5f, Cy = viewComp?.RelativeY ?? 0.5f };
        motion = new ViewMotionProcessor(p.View);
        viewEnabled = true;
        accX = accY = 0;
        EffectiveHz = ViewMotionProcessor.EffectiveHz(p.View, ex.MaxSustainableHz);
        periodMs = Math.Max(1, 1000 / EffectiveHz);
    }

    public void Stop()
    {
        lock (gate)
        {
            if (!running) return;
            running = false;
            ReleaseAllLocked();
            queue.Add(() => ex.ReleaseAll());   // por último: solta tudo e fecha shell/conexões do executor
        }
        queue.CompleteAdding();
        worker?.Join(1500);
        ticker?.Join(500);
    }

    public void Dispose() => Stop();

    // ---------------- entrada ----------------
    /// <summary>true = o evento pertence ao mapeamento e deve ser consumido (não chega ao jogo/sistema).</summary>
    public bool OnKey(int code, bool isDown)
    {
        lock (gate)
        {
            if (!running || profile == null) return false;
            bool consumed = false;
            bool changed = isDown ? down.Add(code) : down.Remove(code);   // false = auto-repeat / evento duplicado

            if (analog != null && IsAnalogKey(code))
            {
                consumed = true;
                if (changed) UpdateAnalog();
            }
            if (viewComp != null && viewComp.KeyCode != 0 && viewComp.KeyCode == code)
            {
                consumed = true;
                if (isDown && changed) ToggleView();
            }
            if (byKey.TryGetValue(code, out var list))
            {
                consumed = true;
                if (changed) foreach (var c in list) HandleComponent(c, isDown);
            }
            return consumed;
        }
    }

    public void OnMouseMove(float dx, float dy)
    {
        lock (gate)
        {
            if (!running) return;
            accX += dx; accY += dy;
        }
    }

    public void OnMouseButton(int evdevButton, bool isDown) => OnKey(InputCodes.MouseBase + evdevButton, isDown);

    // ---------------- componentes ----------------
    bool IsAnalogKey(int code) =>
        code != 0 && (code == analog!.KeyUp || code == analog.KeyDown || code == analog.KeyLeft || code == analog.KeyRight);

    void HandleComponent(HudComponent c, bool isDown)
    {
        switch (c.Kind)
        {
            case ComponentKind.Tap:
                if (isDown) { float x = c.RelativeX, y = c.RelativeY; Post(() => ex.Tap(x, y)); }
                break;
            case ComponentKind.Press:
            case ComponentKind.Shoot:
                if (isDown) BeginPress(c); else EndPress(c);
                break;
            case ComponentKind.Macro:
                if (isDown) StartMacro(c); else StopMacro(c);
                break;
        }
    }

    int AllocPtr()
    {
        for (int i = FirstFreePtr; i <= LastPtr; i++)
            if (!ptrUsed[i]) { ptrUsed[i] = true; return i; }
        return -1;   // sem ponteiros livres: o toque é ignorado (nunca trava)
    }

    void BeginPress(HudComponent c)
    {
        if (pressed.ContainsKey(c.Id)) return;
        int id = AllocPtr();
        if (id < 0) return;
        pressed[c.Id] = new Drag { Ptr = id, Cx = c.RelativeX, Cy = c.RelativeY, Active = true };
        pressedAims[c.Id] = c.Kind == ComponentKind.Shoot;
        float x = c.RelativeX, y = c.RelativeY;
        Post(() => ex.BeginHold(id, x, y));
    }

    void EndPress(HudComponent c)
    {
        if (!pressed.Remove(c.Id, out var d)) return;
        pressedAims.Remove(c.Id);
        ptrUsed[d.Ptr] = false;
        int id = d.Ptr;
        Post(() => ex.EndHold(id));
    }

    void StartMacro(HudComponent c)
    {
        if (macros.ContainsKey(c.Id)) return;
        var cts = new CancellationTokenSource();
        macros[c.Id] = cts;
        float x = c.RelativeX, y = c.RelativeY;
        int interval = Math.Clamp(c.MacroIntervalMs, 20, 5000);
        Task.Run(async () =>
        {
            try
            {
                while (!cts.IsCancellationRequested)
                {
                    Post(() => ex.Tap(x, y));
                    await Task.Delay(interval, cts.Token);
                }
            }
            catch (OperationCanceledException) { }
        });
    }

    void StopMacro(HudComponent c)
    {
        if (macros.Remove(c.Id, out var cts)) cts.Cancel();
    }

    void ToggleView()
    {
        viewEnabled = !viewEnabled;
        accX = accY = 0;
        motion?.Reset();
        if (!viewEnabled) EndViewDrag();   // "seta" ligada: o mouse deixa de mirar
    }

    void UpdateAnalog()
    {
        var a = analog!;
        bool up = a.KeyUp != 0 && down.Contains(a.KeyUp), dn = a.KeyDown != 0 && down.Contains(a.KeyDown);
        bool lf = a.KeyLeft != 0 && down.Contains(a.KeyLeft), rt = a.KeyRight != 0 && down.Contains(a.KeyRight);
        float dx = (rt ? 1 : 0) - (lf ? 1 : 0), dy = (dn ? 1 : 0) - (up ? 1 : 0);

        if (dx == 0 && dy == 0)
        {
            if (analogHeld) { analogHeld = false; Post(() => ex.EndHold(AnalogPtr)); }
            return;
        }
        float len = MathF.Sqrt(dx * dx + dy * dy);
        dx /= len; dy /= len;

        var (w, h) = screen();
        float radiusPx = a.RelativeSize * Math.Min(w, h) / 2f;
        float cx = a.RelativeX, cy = a.RelativeY;
        float tx = Math.Clamp(cx + dx * radiusPx / w, 0f, 1f), ty = Math.Clamp(cy + dy * radiusPx / h, 0f, 1f);

        if (!analogHeld)
        {
            analogHeld = true;
            Post(() => ex.BeginHold(AnalogPtr, cx, cy));
        }
        PostMove(() => ex.MoveHold(AnalogPtr, tx, ty));
    }

    // ---------------- Vista / mira ----------------
    void EndViewDrag()
    {
        if (!viewDrag.Active) return;
        viewDrag.Active = false;
        viewDrag.OffX = viewDrag.OffY = 0;
        Post(() => ex.EndHold(ViewPtr));
    }

    void Tick()
    {
        lock (gate)
        {
            if (!running || profile == null || motion == null) return;
            float dx = accX, dy = accY;
            accX = accY = 0;
            if (!viewEnabled) return;

            // com Tiro segurado (e mira), o mouse arrasta o dedo do Tiro; senão arrasta o dedo da Vista
            Drag? target = null; bool isShoot = false;
            foreach (var (id, d) in pressed) if (pressedAims[id]) { target = d; isShoot = true; }
            if (target == null && viewComp != null) target = viewDrag;
            if (target == null) return;

            var (ox, oy) = motion.Process(dx, dy);
            bool moving = MathF.Abs(ox) > 0.01f || MathF.Abs(oy) > 0.01f;
            long now = clock.ElapsedMilliseconds;

            if (moving)
            {
                var (w, h) = screen();
                float limX = DragRadiusOfShortSide * Math.Min(w, h) / w, limY = DragRadiusOfShortSide * Math.Min(w, h) / h;

                if (!target.Active)
                {
                    target.Active = true; target.OffX = target.OffY = 0;
                    float sx = target.Cx, sy = target.Cy; int p = target.Ptr;
                    Post(() => ex.BeginHold(p, sx, sy));
                }
                target.OffX += ox / w; target.OffY += oy / h;

                if (!isShoot && (MathF.Abs(target.OffX) > limX || MathF.Abs(target.OffY) > limY))
                {
                    // chegou na borda: solta e recomeça no centro (o jogo vê um novo arrasto)
                    float sx = target.Cx, sy = target.Cy; int p = target.Ptr;
                    target.OffX = target.OffY = 0;
                    Post(() => ex.EndHold(p));
                    Post(() => ex.BeginHold(p, sx, sy));
                }
                else
                {
                    target.OffX = Math.Clamp(target.OffX, -limX, limX);   // Tiro: não solta; fica limitado ao raio
                    target.OffY = Math.Clamp(target.OffY, -limY, limY);
                }
                float px = Math.Clamp(target.Cx + target.OffX, 0f, 1f), py = Math.Clamp(target.Cy + target.OffY, 0f, 1f);
                int pid = target.Ptr;
                PostMove(() => ex.MoveHold(pid, px, py));
                target.LastMoveMs = now;
            }
            else if (!isShoot && target.Active && now - target.LastMoveMs > ViewIdleMs)
            {
                EndViewDrag();   // parado: não deixa um dedo "preso" na tela
            }
        }
    }

    // ---------------- soltar tudo ----------------
    void ReleaseAllLocked()
    {
        foreach (var cts in macros.Values) cts.Cancel();
        macros.Clear();
        foreach (var d in pressed.Values) { int id = d.Ptr; Post(() => ex.EndHold(id)); }
        pressed.Clear(); pressedAims.Clear();
        Array.Clear(ptrUsed);
        if (analogHeld) { analogHeld = false; Post(() => ex.EndHold(AnalogPtr)); }
        if (viewDrag.Active) { viewDrag.Active = false; Post(() => ex.EndHold(ViewPtr)); }
        down.Clear();
        accX = accY = 0;
    }

    // ---------------- execução em thread própria ----------------
    void Post(Action a) { try { queue.Add(a); } catch (InvalidOperationException) { } }

    /// <summary>Movimentos podem ser descartados se o executor estiver atrasado (o próximo já traz a posição mais nova).</summary>
    void PostMove(Action a)
    {
        if (queue.Count < 6) Post(a);
    }

    void WorkerLoop()
    {
        foreach (var a in queue.GetConsumingEnumerable())
        {
            try { a(); } catch (Exception) { /* um executor com problema não pode derrubar o motor */ }
        }
    }

    void TickLoop()
    {
        var sw = Stopwatch.StartNew();
        double next = 0;
        while (running)
        {
            try { Tick(); } catch (Exception) { }
            next += periodMs;
            double wait = next - sw.Elapsed.TotalMilliseconds;
            if (wait > 1) Thread.Sleep((int)wait);
            else if (wait < -200) next = sw.Elapsed.TotalMilliseconds;   // ficou muito atrasado: não tenta recuperar
        }
    }
}
