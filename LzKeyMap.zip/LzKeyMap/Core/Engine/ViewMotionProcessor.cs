using LzKeyMap.Core.Models;

namespace LzKeyMap.Core.Engine;

/// <summary>
/// Aplica as ViewSettings ao movimento bruto do mouse. Independente de Android e do MappingEngine:
/// o motor só precisa chamar Process(dx, dy) a cada delta e usar EffectiveHz para o ritmo de saída.
///
/// Convenções (ajuste se o motor da Fase 1 já usar outras):
///  - dx/dy em contagens brutas do mouse.
///  - DeadZone 0..1 -> descarta deltas cujo módulo bruto seja menor que DeadZone * DeadZoneMaxCounts.
///  - Smoothing 0..1 -> filtro exponencial; 0 = sem suavização, ~1 = muito suave (mais atraso).
///  - Saída = delta * SensibilidadeEixo * MouseSpeed, com inversão por eixo.
/// </summary>
public sealed class ViewMotionProcessor
{
    public const float DeadZoneMaxCounts = 5f;

    ViewSettings s;
    float prevX, prevY;

    public ViewMotionProcessor(ViewSettings settings) => s = settings;

    public void Update(ViewSettings settings) { s = settings; Reset(); }
    public void Reset() { prevX = prevY = 0; }

    public (float X, float Y) Process(float dx, float dy)
    {
        float mag = MathF.Sqrt(dx * dx + dy * dy);
        if (mag < (float)s.DeadZone * DeadZoneMaxCounts) { dx = 0; dy = 0; }

        float ox = dx * (float)s.SensitivityX * (float)s.MouseSpeed * (s.InvertX ? -1f : 1f);
        float oy = dy * (float)s.SensitivityY * (float)s.MouseSpeed * (s.InvertY ? -1f : 1f);

        float k = 1f - Math.Clamp((float)s.Smoothing, 0f, 0.95f);   // fator de passagem
        prevX += (ox - prevX) * k;
        prevY += (oy - prevY) * k;
        return (prevX, prevY);
    }

    /// <summary>Hz realmente aplicado: nunca acima do que o método de execução sustenta.</summary>
    public static int EffectiveHz(ViewSettings v, int executorMaxSustainableHz)
    {
        int wanted = Convert.ToInt32(v.Frequency);
        return Math.Max(1, Math.Min(wanted, executorMaxSustainableHz));
    }
}
