using LzKeyMap.Core.Models;

namespace LzKeyMap.Core.Abstractions;

public sealed record InstalledApp(string PackageName, string Label, bool IsGame);

public interface IGameCatalog
{
    /// <summary>Apps com Intent.CategoryLauncher (reais, via PackageManager).</summary>
    Task<IReadOnlyList<InstalledApp>> GetLaunchableAppsAsync();
    bool Launch(string packageName);
}

public interface IFileTransfer
{
    /// <summary>Seletor nativo (ActionOpenDocument). Devolve caminho de um arquivo temporário copiado, ou null se cancelado.</summary>
    Task<string?> PickImportFileAsync();
    /// <summary>Seletor nativo (ActionCreateDocument). Copia sourcePath para o destino escolhido.</summary>
    Task<bool> SaveExportFileAsync(string sourcePath, string suggestedName);
}

public interface IHudEditorLauncher
{
    bool IsRunning { get; }
    bool Start(HudProfile profile, out string message);
    void Stop();
}

/// <summary>
/// Fachada fina sobre o que a Home da Fase 1 já faz ao tocar em INICIAR/PARAR
/// (iniciar MappingForegroundService + motor com o HUD dado). Implemente em 10 linhas chamando o código existente.
/// </summary>
public interface IEngineController
{
    bool IsRunning { get; }
    /// <summary>Avisos reais da última partida (ex.: "mouse não capturado: ..."); null se não houve.</summary>
    string? Note { get; }
    /// <summary>null = iniciou de verdade; texto = motivo real da falha (nenhum método disponível, etc.).</summary>
    Task<string?> StartAsync(HudProfile hud);
    void Stop();
}

public interface ISystemSettingsLauncher
{
    bool Open(string permissionId, out string message);
}

/// <summary>Perfil em edição / ativo para as telas de configuração. Alterações persistem só via ProfileStore.</summary>
public static class EditorSession
{
    public static HudProfile? Profile { get; set; }
    public static event Action? ProfileSaved;
    public static void RaiseSaved() => ProfileSaved?.Invoke();
}
