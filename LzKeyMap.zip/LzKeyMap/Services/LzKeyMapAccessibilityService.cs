using Android.AccessibilityServices;
using Android.App;
using Android.Content;
using Android.Views;
using Android.Views.Accessibility;
using LzKeyMap.Core.Devices;

namespace LzKeyMap.Services;

/// <summary>
/// Serviço de Acessibilidade real: recebe TODAS as teclas do sistema (canRequestFilterKeyEvents) e despacha toques
/// (canPerformGestures, via AccessibilityInputExecutor). O mouse NÃO chega por aqui (só por Root/evdev).
/// </summary>
[Service(Name = ServiceName, Label = "LzKeyMap", Permission = "android.permission.BIND_ACCESSIBILITY_SERVICE", Exported = true)]
[IntentFilter(new[] { "android.accessibilityservice.AccessibilityService" })]
[MetaData("android.accessibilityservice", Resource = "@xml/accessibility_service_config")]
public class LzKeyMapAccessibilityService : AccessibilityService
{
    public const string ServiceName = "com.lz.keymap.LzKeyMapAccessibilityService";

    public static LzKeyMapAccessibilityService? Instance { get; private set; }

    protected override void OnServiceConnected()
    {
        base.OnServiceConnected();
        var info = ServiceInfo;
        if (info != null)
        {
            info.Flags |= ServiceFlags.RequestFilterKeyEvents;
            ServiceInfo = info;
        }
        Instance = this;
    }

    public override bool OnUnbind(Intent? intent)
    {
        Instance = null;
        return base.OnUnbind(intent);
    }

    public override void OnDestroy()
    {
        Instance = null;
        base.OnDestroy();
    }

    public override void OnAccessibilityEvent(AccessibilityEvent? e) { }
    public override void OnInterrupt() { }

    protected override bool OnKeyEvent(KeyEvent? e)
    {
        if (e == null) return false;
        if (e.Action != KeyEventActions.Down && e.Action != KeyEventActions.Up) return false;

        bool down = e.Action == KeyEventActions.Down;
        int code = (int)e.KeyCode;

        // decidir ANTES de publicar: publicar pode consumir a captura de tecla do editor
        bool suppress = InputEventHub.SuppressEngine;
        InputEventHub.PublishKey(code, e.KeyCode.ToString(), down);

        if (suppress) return true;   // modo teste / captura de tecla: consome e NÃO aciona o HUD
        return MappingForegroundService.Engine?.OnKey(code, down) ?? false;
    }
}
