using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Provider;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using LzKeyMap.Core.Abstractions;
using LzKeyMap.Core.Execution;
using LzKeyMap.Core.Models;
using LzKeyMap.Core.Storage;
using LzKeyMap.Overlay;
using View = Android.Views.View;
using Orientation = Android.Widget.Orientation;

namespace LzKeyMap.Services;

/// <summary>
/// Barra flutuante (TYPE_APPLICATION_OVERLAY) com Sair / Adicionar / Salvar / Config + janela de edição em tela cheia.
/// A barra só existe enquanto se edita: abrir = modo edição ligado; Sair = fecha tudo.
/// Requer "Sobrepor a outros apps". HUD editado vem de EditorSession.Profile e TODA gravação passa por ProfileStore.Save.
/// </summary>
[Service(Exported = false)]
public class FloatingToolbarService : Service
{
    public const string ExtraStop = "lzkeymap.stop_toolbar";
    public static bool Running { get; private set; }

    IWindowManager? wm;
    LinearLayout? bar;
    LinearLayout? menu;
    EditorCanvas? canvas;
    WindowManagerLayoutParams? barLp, menuLp;
    HudProfile? profile;
    ProfileStore? store;
    IExecutionManager? execution;
    bool collapsed;
    TextView? handle;
    readonly List<View> collapsible = new();

    int Dp(int v) => (int)(v * Resources!.DisplayMetrics!.Density);
    void Say(string msg) => Toast.MakeText(this, msg, ToastLength.Short)?.Show();

    public override IBinder? OnBind(Intent? intent) => null;

    public override StartCommandResult OnStartCommand(Intent? intent, StartCommandFlags flags, int startId)
    {
        if (intent?.GetBooleanExtra(ExtraStop, false) == true) { StopSelf(); return StartCommandResult.NotSticky; }
        if (bar != null) return StartCommandResult.NotSticky;

        if (!Settings.CanDrawOverlays(this))
        { Say("Permissão de sobreposição não concedida."); StopSelf(); return StartCommandResult.NotSticky; }

        profile = EditorSession.Profile;
        if (profile == null) { Say("Nenhum HUD carregado para edição."); StopSelf(); return StartCommandResult.NotSticky; }
        profile.View ??= ViewSettings.Defaults();

        var services = Microsoft.Maui.IPlatformApplication.Current?.Services;
        store = services?.GetService(typeof(ProfileStore)) as ProfileStore;
        execution = services?.GetService(typeof(IExecutionManager)) as IExecutionManager;
        if (store == null) { Say("ProfileStore indisponível (DI)."); StopSelf(); return StartCommandResult.NotSticky; }

        wm = GetSystemService(WindowService)!.JavaCast<IWindowManager>();
        BuildBar();
        EnterEdit();
        Running = true;
        return StartCommandResult.NotSticky;
    }

    WindowManagerLayoutParams OverlayParams(int w, int h, WindowManagerFlags flags) =>
        new(w, h, WindowManagerTypes.ApplicationOverlay, flags, Format.Translucent)
        { Gravity = GravityFlags.Top | GravityFlags.Start };

    // ---------- barra ----------
    View Item(int icon, string text, Action onClick)
    {
        var row = new LinearLayout(this) { Orientation = Orientation.Horizontal };
        row.SetGravity(GravityFlags.CenterVertical);
        row.SetPadding(Dp(8), Dp(4), Dp(8), Dp(4));
        var iv = new ImageView(this);
        iv.SetImageResource(icon);
        iv.SetColorFilter(Palette.Pink);
        row.AddView(iv, new LinearLayout.LayoutParams(Dp(22), Dp(22)));
        var tv = Ui.Label(this, text, 11);
        tv.SetPadding(Dp(5), 0, 0, 0);
        row.AddView(tv);
        row.Click += (_, _) => onClick();
        collapsible.Add(row);
        return row;
    }

    View Divider()
    {
        var v = new View(this);
        v.SetBackgroundColor(Palette.PinkDark);
        collapsible.Add(v);
        v.LayoutParameters = new LinearLayout.LayoutParams(Dp(1), Dp(22));
        return v;
    }

    void BuildBar()
    {
        bar = new LinearLayout(this) { Orientation = Orientation.Horizontal };
        bar.SetGravity(GravityFlags.CenterVertical);
        bar.Background = new ChevronBarDrawable(Dp(16), Dp(2));
        bar.SetPadding(Dp(14), Dp(5), Dp(14), Dp(5));

        // a "alça" arrasta a barra; um toque simples minimiza/expande
        handle = Ui.Label(this, "⋮⋮", 14, Palette.Pink);
        handle.SetPadding(Dp(6), Dp(4), Dp(10), Dp(4));
        bar.AddView(handle);

        bar.AddView(Item(Android.Resource.Drawable.IcMenuCloseClearCancel, "Sair", StopSelfBar));
        bar.AddView(Divider());
        bar.AddView(Item(Android.Resource.Drawable.IcMenuAdd, "Adicionar", ToggleMenu));
        bar.AddView(Divider());
        bar.AddView(Item(Android.Resource.Drawable.IcMenuSave, "Salvar", SaveClicked));
        bar.AddView(Divider());
        bar.AddView(Item(Android.Resource.Drawable.IcMenuPreferences, "Config", () => canvas?.ToggleSettings()));

        barLp = OverlayParams(ViewGroup.LayoutParams.WrapContent, ViewGroup.LayoutParams.WrapContent,
            WindowManagerFlags.NotFocusable | WindowManagerFlags.NotTouchModal);
        barLp.X = Dp(140); barLp.Y = Dp(24);

        float downX = 0, downY = 0; int startX = 0, startY = 0; bool moved = false;
        handle.Touch += (_, e) =>
        {
            var ev = e.Event!;
            switch (ev.ActionMasked)
            {
                case MotionEventActions.Down:
                    downX = ev.RawX; downY = ev.RawY; startX = barLp!.X; startY = barLp.Y; moved = false; break;
                case MotionEventActions.Move:
                    if (Math.Abs(ev.RawX - downX) > Dp(6) || Math.Abs(ev.RawY - downY) > Dp(6)) moved = true;
                    if (!moved) break;
                    barLp!.X = startX + (int)(ev.RawX - downX);
                    barLp.Y = startY + (int)(ev.RawY - downY);
                    wm!.UpdateViewLayout(bar, barLp);
                    CloseMenu();
                    break;
                case MotionEventActions.Up:
                    // o Touch consome o evento, então o Click nunca dispara: o toque simples é tratado aqui
                    if (!moved) ToggleCollapse();
                    break;
            }
            e.Handled = true;
        };

        wm!.AddView(bar, barLp);
    }

    void ToggleCollapse()
    {
        collapsed = !collapsed;
        foreach (var v in collapsible) v.Visibility = collapsed ? ViewStates.Gone : ViewStates.Visible;
        handle!.Text = collapsed ? "LZ" : "⋮⋮";   // minimizado: só a alça, vira o botão flutuante
        CloseMenu();
        wm!.UpdateViewLayout(bar, barLp);
    }

    void StopSelfBar() => StopSelf();

    // ---------- edição ----------
    void EnterEdit()
    {
        if (canvas != null || profile == null) return;
        var dm = new DisplayMetrics();
#pragma warning disable CA1422
        wm!.DefaultDisplay!.GetRealMetrics(dm);
#pragma warning restore CA1422
        canvas = new EditorCanvas(this, profile, Say, SaveNow, FreqNote);
        var lp = OverlayParams(dm.WidthPixels, dm.HeightPixels,
            WindowManagerFlags.NotFocusable | WindowManagerFlags.LayoutInScreen | WindowManagerFlags.LayoutNoLimits);
        lp.X = 0; lp.Y = 0;
        wm.AddView(canvas, lp);
        BringBarToFront();
    }

    void BringBarToFront()
    {
        if (bar == null || wm == null) return;
        wm.RemoveView(bar);
        wm.AddView(bar, barLp);
    }

    /// <summary>Nunca esconde a diferença entre o Hz pedido e o que o método de execução sustenta.</summary>
    string FreqNote()
    {
        int wanted = Convert.ToInt32(profile!.View.Frequency);
        var ex = execution?.Active;
        if (ex == null) return "Sem método de execução ativo: o limite real de Hz é desconhecido (inicie o motor na Home).";
        return ex.MaxSustainableHz < wanted
            ? $"Limite real de {ex.Name}: {ex.MaxSustainableHz} Hz. Você pediu {wanted} Hz; o valor aplicado será {ex.MaxSustainableHz} Hz."
            : $"{ex.Name} sustenta até {ex.MaxSustainableHz} Hz.";
    }

    // ---------- adicionar ----------
    void ToggleMenu()
    {
        if (menu != null) { CloseMenu(); return; }
        EnterEdit();

        menu = new LinearLayout(this) { Orientation = Orientation.Vertical };
        menu.Background = Ui.Round(this, Palette.Panel, Palette.PinkDark, 10, 1);
        menu.SetPadding(Dp(4), Dp(4), Dp(4), Dp(4));

        foreach (var kind in ComponentKindInfo.All)
        {
            var k = kind;
            var t = Ui.Label(this, k.Label(), 12);
            t.Gravity = GravityFlags.Center;
            t.SetPadding(Dp(28), Dp(9), Dp(28), Dp(9));
            t.Click += (_, _) => { CloseMenu(); canvas?.BeginPlacement(k); };
            menu.AddView(t);
        }

        menuLp = OverlayParams(ViewGroup.LayoutParams.WrapContent, ViewGroup.LayoutParams.WrapContent,
            WindowManagerFlags.NotFocusable | WindowManagerFlags.NotTouchModal);
        menuLp.X = barLp!.X + Dp(60);
        menuLp.Y = barLp.Y + Math.Max(bar!.Height, Dp(44)) + Dp(4);
        wm!.AddView(menu, menuLp);
    }

    void CloseMenu()
    {
        if (menu == null) return;
        wm!.RemoveView(menu);
        menu = null;
    }

    // ---------- salvar ----------
    bool SaveNow()
    {
        try
        {
            store!.Save(profile!);
            EditorSession.RaiseSaved();
            return true;
        }
        catch (Exception ex)
        {
            Say("Falha ao salvar o HUD: " + ex.Message);
            return false;
        }
    }

    void SaveClicked()
    {
        if (SaveNow()) Say($"HUD \"{profile!.Name}\" salvo ({profile.Components.Count} componentes).");
    }

    public override void OnDestroy()
    {
        try
        {
            CloseMenu();
            if (canvas != null) { wm?.RemoveView(canvas); canvas = null; }
            if (bar != null) { wm?.RemoveView(bar); bar = null; }
        }
        catch (Exception) { /* janela já removida pelo sistema */ }
        Running = false;
        base.OnDestroy();
    }
}
