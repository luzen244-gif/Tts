using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using LzKeyMap.Core.Abstractions;
using LzKeyMap.Core.Devices;
using LzKeyMap.Core.Engine;
using LzKeyMap.Core.Execution;
using LzKeyMap.Core.Models;

namespace LzKeyMap.Services;

/// <summary>Hospeda o MappingEngine em primeiro plano (o Android mata serviços comuns quando o jogo ocupa a tela).</summary>
[Service(Exported = false, ForegroundServiceType = ForegroundService.TypeSpecialUse)]
public class MappingForegroundService : Service
{
    public const string ActionStop = "lzkeymap.stop_engine";
    const string ChannelId = "lzkeymap_engine";
    const int NotificationId = 4101;

    public static MappingEngine? Engine { get; private set; }
    public static bool IsRunning => Engine?.Running == true;

    /// <summary>Entregues pelo EngineController antes de iniciar o serviço.</summary>
    public static HudProfile? PendingHud { get; set; }
    public static IInputExecutor? PendingExecutor { get; set; }

    HudProfile? hud;

    public override IBinder? OnBind(Intent? intent) => null;

    public override StartCommandResult OnStartCommand(Intent? intent, StartCommandFlags flags, int startId)
    {
        if (intent?.Action == ActionStop) { StopSelf(); return StartCommandResult.NotSticky; }

        var h = PendingHud; var ex = PendingExecutor;
        if (h == null || ex == null) { StopSelf(); return StartCommandResult.NotSticky; }
        hud = h;

        CreateChannel();
        var n = BuildNotification(h, ex);
        if (Build.VERSION.SdkInt >= BuildVersionCodes.Q)
            StartForeground(NotificationId, n, ForegroundService.TypeSpecialUse);
        else
            StartForeground(NotificationId, n);

        Engine?.Stop();
        Engine = new MappingEngine(ex, ScreenInfo.Size);
        Engine.Start(h);
        EditorSession.ProfileSaved += OnProfileSaved;   // edição no overlay vale na hora, sem reiniciar
        return StartCommandResult.NotSticky;
    }

    void OnProfileSaved()
    {
        var edited = EditorSession.Profile;
        if (edited != null && hud != null && edited.Id == hud.Id) Engine?.Reload(edited);
    }

    void CreateChannel()
    {
        var nm = (NotificationManager)GetSystemService(NotificationService)!;
        if (nm.GetNotificationChannel(ChannelId) == null)
            nm.CreateNotificationChannel(new NotificationChannel(ChannelId, "Motor de mapeamento", NotificationImportance.Low));
    }

    Notification BuildNotification(HudProfile h, IInputExecutor ex)
    {
        var stop = new Intent(this, typeof(MappingForegroundService)).SetAction(ActionStop);
        var stopPi = PendingIntent.GetService(this, 0, stop, PendingIntentFlags.Immutable | PendingIntentFlags.UpdateCurrent);
        var open = PackageManager!.GetLaunchIntentForPackage(PackageName!);
        var openPi = open == null ? null : PendingIntent.GetActivity(this, 1, open, PendingIntentFlags.Immutable);

        return new Notification.Builder(this, ChannelId)
            .SetContentTitle("LzKeyMap ativo")
            .SetContentText($"HUD \"{h.Name}\" · método {ex.Name}")
            .SetSmallIcon(Android.Resource.Drawable.IcMediaPlay)
            .SetOngoing(true)
            .SetContentIntent(openPi)
            .AddAction(new Notification.Action.Builder(null, "Parar", stopPi).Build())
            .Build()!;
    }

    public override void OnDestroy()
    {
        EditorSession.ProfileSaved -= OnProfileSaved;
        try { Engine?.Stop(); } catch (Exception) { }
        Engine = null;
        RawInputService.Instance.Stop();
        base.OnDestroy();
    }
}
